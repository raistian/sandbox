// Test warning with Ref Cursor in Callback
var warnTest = function() {
  apex.server.process('warnTest',{
    'x01':$('#P25_FORM_ID').val(),  // Form ID
    'x02': '41.'                    // question_reference
  }).then(function(data) {
    // console.log(data);
    var parentObjects = [];
    var childObjects  = [];
    
    data.result.forEach(function(theResult) {
      
      theResult.parent_answers.forEach(function(parentAnswer) {
        if ( $('[id='+parentAnswer.dom_id+']').hasClass('pillSelected') && parentAnswer.score > 0) {
          parentObjects.push(parentAnswer);
        }
      });
      
      theResult.child_questions.forEach(function(childQuestion) {
        childQuestion.child_answers.forEach(function(childAnswer) {
          if ( $('[id='+childAnswer.dom_id+']').hasClass('pillSelected') && childAnswer.score > 0 ) { // All children with positive score ie. Yes
            var childQA = { // Combine childQuestion and childAnswer properties to make it easier to make warning message
              questionRef: childQuestion.question_reference,
              questionId:  childQuestion.question_id,
              answerDomId: childAnswer.dom_id,
              answerScore: childAnswer.score,
              answerText:  childAnswer.answer_text
            };
            childObjects.push(childQA);
          }
        });
      });
      
    });

/*
    var childA = childObjects.find( function(i) {
      return i.questionRef === 'a)';
    });
    
    var otherCt = 0;
    childObjects.forEach(function(c) {
      if (c.questionRef !== 'a)' ) {
        otherCt += 1;
      }
    });
    
    if (!(parentObjects.length > 0 && childA && otherCt > 0)) {
      apex.message.clearErrors();
      childObjects.forEach(function(childObject) {      
        var warningMsg = 'Question '+parentObjects[0].question_reference+ childObject.questionRef + '|' + childObject.answerText;
        // console.log(warningMsg);
        apex.message.showErrors([{
          type: apex.message.TYPE.ERROR,
          location: ["page"],
          message: warningMsg,
          unsafe: false
        }]);
      });
      console.log('Falsy');
      return false;
    }      
    // No warnings when this part is reached
    console.log('Truey');
    return true;
*/
  }, 'Error at Question 41 Warning calculations');
} // end of function