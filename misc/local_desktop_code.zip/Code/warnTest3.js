// Test warning with Ref Cursor in Callback
var warnTest = function() {
  $("#saveButton").prop('disabled', true);
  var warnings = [];
  var callback = 'warnTest';
  
  // If LS Assessment (LS/RNR) Form
  if ($('#P25_FORM_CODE').val() == 'LS/RNR') {
    apex.server.process(callback,{
      'x01':$('#P25_FORM_ID').val(),  // Form ID
      'x02': '41.'                    // question_reference
    }).then(function(data) {
      var theParent;
      var validCt = 0;
      data.result.forEach(function(theResult) {
        theResult.parent_answers.forEach(function(parentAnswer) {
          if ( $('[id=' + parentAnswer.dom_id + ']').hasClass('pillSelected') && parentAnswer.score > 0) { // Parent has positive score
            theParent = parentAnswer;
          }
        });
        
        if (theParent) {
          theResult.child_questions.forEach(function(childQuestion) {
            childQuestion.child_answers.forEach(function(childAnswer) {
              if ( $('[id=' + childAnswer.dom_id + ']').hasClass('pillSelected') ) { // All children with answers
                // Weigthing points: a) is 100, b), c), d) is 1 each.
                if (childAnswer.question_reference === 'a)') {
                  validCt += 100;
                } else {
                  validCt += 1;
                }
              }
            });
          });
          // Set warning message if point's too low
          if (validCt <= 100) {
            var questionTopOffset = $('[id=questionId-' + theParent.question_id + ']').offset().top - ($('#t_Body_title').height() + 100);
            var questionUrl = '<a href="javascript:$(\'html, body\').animate({scrollTop: '+ (questionTopOffset) + '});">(show)</a>';
            warnings.push('Question 41 is Yes. Must complete item a) plus at least one of b), c), or d) ' + questionUrl);
          }
        }
      });

      return apex.server.process(callback,{
        'x01':$('#P25_FORM_ID').val(),  // Form ID
        'x02': '42.'                    // question_reference
      });
    }, 'Error: LS Question 41').then(function(data) {
      var theParent;
      var validCt = 0;
      data.result.forEach(function(theResult) {
        theResult.parent_answers.forEach(function(parentAnswer) {
          if ( $('[id=' + parentAnswer.dom_id + ']').hasClass('pillSelected') && parentAnswer.score > 0) { // Parent has positive score
            theParent = parentAnswer;
          }
        });
        
        if (theParent) {
          theResult.child_questions.forEach(function(childQuestion) {
            childQuestion.child_answers.forEach(function(childAnswer) {
              if ( $('[id=' + childAnswer.dom_id + ']').hasClass('pillSelected') ) { // All children with answers
                // Weigthing points: 1 for each child answer
                validCt += 1;
              }
            });
          });
          // Set warning message if point's too low
          if (validCt < 1) {
            var questionTopOffset = $('[id=questionId-' + theParent.question_id + ']').offset().top - ($('#t_Body_title').height() + 100);
            var questionUrl = '<a href="javascript:$(\'html, body\').animate({scrollTop: '+ (questionTopOffset) + '});">(show)</a>';
            warnings.push('Question 42 is Yes. Must complete at least one child question ' + questionUrl);
          }
        }
      });
      
      return apex.server.process(callback,{
        'x01':$('#P25_FORM_ID').val(),  // Form ID
        'x02': '43.'                    // question_reference
      });
    }, 'Error: LS Question 42').then(function(data) {
      var theParent;
      var validCt = 0;
      data.result.forEach(function(theResult) {
        theResult.parent_answers.forEach(function(parentAnswer) {
          if ( $('[id=' + parentAnswer.dom_id + ']').hasClass('pillSelected') && parentAnswer.score > 0) { // Parent has positive score
            theParent = parentAnswer;
          }
        });
        
        if (theParent) {
          theResult.child_questions.forEach(function(childQuestion) {
            childQuestion.child_answers.forEach(function(childAnswer) {
              if ( $('[id=' + childAnswer.dom_id + ']').hasClass('pillSelected') ) { // All children with answers
                // Weigthing points: 1 for each child answer
                validCt += 1;
              }
            });
          });
          // Set warning message if point's too low
          if (validCt < 4) {
            var questionTopOffset = $('[id=questionId-' + theParent.question_id + ']').offset().top - ($('#t_Body_title').height() + 100);
            var questionUrl = '<a href="javascript:$(\'html, body\').animate({scrollTop: '+ (questionTopOffset) + '});">(show)</a>';
            warnings.push('Question 43 is Yes. Must complete at least four of its child questions ' + questionUrl);
          }
        }
      });
    }, 'Error: LS Question 43').then(function(data) {
      if (warnings.length > 0) {
        // Show warning messages if any
        apex.message.clearErrors();
        warnings.forEach(function(warning) {
          apex.message.showErrors([{
            type: apex.message.TYPE.ERROR,
            location: ["page"],
            message: warning,
            unsafe: false
          }]);
        });
        // Re-enable button
        $("#saveButton").prop('disabled', false);
        return false;
      }
      // No warnings if this line is reached
      return true;
    }, 'Error: LS Show Warning').then(function(bool) {
      if (bool) {
        apex.submit({request:'SAVE',validate:true});
      }
    }, 'Error: LS Submit');
  }
  else if ($('#P25_FORM_CODE').val() == 'YLS/CMI 2.0') {
    apex.server.process(callback,{
      'x01':$('#P25_FORM_ID').val(),  // Form ID
      'x02': '5.'                     // question_reference
    }).then(function(data) {
      var mainAnswer;
      var otherAnswers = [];
      data.result.forEach(function(theResult) {
        theResult.child_questions.forEach(function(childQuestion) {
          childQuestion.child_answers.forEach(function(childAnswer) {
            if ( $('[id=' + childAnswer.dom_id + ']').hasClass('pillSelected') ) { // All children with answers
              if (childAnswer.question_reference === 'd)' && childAnswer.score > 0) { // d) is marked
                mainAnswer = childAnswer;
              }
              if ( childAnswer.question_reference === 'b)' || childAnswer.question_reference === 'c)' ) {
                otherAnswers.push(childAnswer);
              }
            }
          });
        });
      });
      if (mainAnswer) {
        var points = 0;;
        otherAnswers.forEach(function(oa) {
          points += oa.score;
        });

        if (points < 1) {
          var questionTopOffset = $('[id=questionId-' + mainAnswer.question_id + ']').offset().top - ($('#t_Body_title').height() + 500);
          var questionUrl = '<a href="javascript:$(\'html, body\').animate({scrollTop: '+ (questionTopOffset) + '});">(show)</a>';
          warnings.push('Question 5d) is selected. One of 5b) or 5c) must be marked ' + questionUrl);
        }
      }
    }, 'Error: YLS Question 5').then(function(data) {
      if (warnings.length > 0) {
        // Show warning messages if any
        apex.message.clearErrors();
        warnings.forEach(function(warning) {
          apex.message.showErrors([{
            type: apex.message.TYPE.ERROR,
            location: ["page"],
            message: warning,
            unsafe: false
          }]);
        });
        // Re-enable button
        $("#saveButton").prop('disabled', false);
        return false;
      }
      // No warnings if this line is reached
      return true;
    }, 'Error: YLS Show Warning').then(function(bool) {
      if (bool) {
        apex.submit({request:'SAVE',validate:true});
      }
    }, 'Error: YLS Submit');
  }
} // end of function