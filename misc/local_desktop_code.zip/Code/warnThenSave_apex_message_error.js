var warnThenSave = function() {
  // If LS Assessment (LS/RNR) Form
  if ($('#P25_FORM_CODE').val() == 'LS/RNR') {   
    var messages    = [];
    var questionIds = [];

    apex.server.process('warnQuestion41_process',{})
      .then(function(data) {
        var parentCt = 0;
        var childCt = 0;
        var parentId = '';
        // Question 41 data
        data.result.forEach(function(row) {
          if ( $('[id='+row.dom_id+']').hasClass('pillSelected') ) {
            if ( row.level == 1 && row.score > 0) { // Parent has Yes answer
              parentCt += 1;
              parentId = row.question_id;
            }
            else if ( row.level == 2 && row.question_reference != 'a)' ) {
              childCt += 1;
            }
          }
        });

        if (parentCt > 0 && childCt < 1) {
          // Set parent question ID and add warning message
          questionIds.push(parentId);
          messages.push('Question 41 is Yes. Must complete item a) plus at least one of b), c), or d)');
        }
        return apex.server.process('warnQuestion42_process',{});
      },'Error@warnQuestion41')
      .then(function(data) {
        var parentCt = 0;
        var childCt = 0;
        var parentId = '';
        // Question 42 data
        data.result.forEach(function(row) {
          if ( $('[id='+row.dom_id+']').hasClass('pillSelected') ) {
            if ( row.level == 1 && row.score > 0) { // Parent has Yes answer
              parentCt += 1;
              parentId = row.question_id;
            }
            else if ( row.level == 2) {
              childCt += 1;
            }
          }
        });

        if (parentCt > 0 && childCt < 1) {
          // Set parent question ID and add warning message
          questionIds.push(parentId);
          messages.push('Question 42 is Yes. Must complete at least one child question');
        }
        return apex.server.process('warnQuestion43_process',{});
      },'Error@warnQuestion42')
      .then(function(data) {
        var parentCt = 0;
        var childCt = 0;
        var parentId = '';
        // Question 43 data
        data.result.forEach(function(row) {
          if ( $('[id='+row.dom_id+']').hasClass('pillSelected') ) {
            if ( row.level == 1 && row.score > 0) { // Parent has Yes answer
              parentCt += 1;
              parentId = row.question_id;
            }
            else if ( row.level == 2 ) {
              childCt += 1;
            }
          }
        });

        if (parentCt > 0 && childCt < 4) {
          // Set parent question ID and add warning message
          questionIds.push(parentId);
          messages.push('Question 43 is Yes. Must complete at least four of its child questions');
        }
      },'Error@warnQuestion43')
      .then(function(data) {
        if (questionIds.length > 0) {

          apex.message.clearErrors();
          
          for (var i=0;i<messages.length;i++) {
            // The form has a top region (breadcrumb) that does not move, so we need to offset its height of approx 390px
            var offset = $('[id=questionAnswerRow-'+questionIds[i]+']').offset();
            apex.message.showErrors([{
              type: apex.message.TYPE.ERROR,
              location: ["page"],
              message: ( messages[i] + ' <a href="javascript:$(\'html, body\').animate({scrollTop: '+ (offset.top-390) + '});">(show)</a>' ),
              unsafe: false
            }]);
          }
          
        }
      },'Error last chain');

  } // if LS Assessment Form
  
} // end of function