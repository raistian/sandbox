/**********************************************************
* YJAT Application - Page 10 JavaScript
**********************************************************/

// Hide or show the client search region
function clientSearchRegion(pHideShow, pSkipAnimate) {
  
  var $searchRegion = $('#CLIENT_SEARCH .t-Region-bodyWrap');

  if (pSkipAnimate == 'SkipAnimate') {
    $searchRegion.addClass('noAnimate');
  }
  else {
    $searchRegion.removeClass('noAnimate');    
  }  
  
  if (pHideShow == 'Hide') {
    $searchRegion.addClass('sliderClosed');
    $('#MINMAX_BUTTON').addClass('fa-rotate-270');
  }
  else {
    $searchRegion.removeClass('sliderClosed');
    $('#MINMAX_BUTTON').removeClass('fa-rotate-270');
  }
}

// Hide or show the client workflow region
function clientWorkFlowRegion(pHideShow, pSkipAnimate) {
  
  var $workFlowRegion = $('#CLIENT_WORKFLOW .t-Region-bodyWrap');

  if (pSkipAnimate == 'SkipAnimate') {
    $workFlowRegion.addClass('noAnimate');
  }
  else {
    $workFlowRegion.removeClass('noAnimate');    
  }  

  if (pHideShow == 'Hide') {
    $workFlowRegion.addClass('sliderClosed');
  }
  else {
    $workFlowRegion.removeClass('sliderClosed');
  }
}

// Refresh the Assessment Region 
function refreshAssessmentRegion(pClientID) {

  $('#P10_CLIENT_ID').val(pClientID);

  // Shrink Client search region and adjust icon
  clientSearchRegion('Hide');

  // Call dynamic action to update page items and refresh report region
  $.event.trigger('refreshClientWorkflow');
}

// Toggle display of client search region
function toggleClientSearch() {

  var currentHideSearch = $('#CLIENT_SEARCH .t-Region-bodyWrap').hasClass('sliderClosed');
  var clientId = $('#P10_CLIENT_ID').val();

  // If search currently hidden then show it
  if (currentHideSearch) {
    clientSearchRegion('Show');
    clientWorkFlowRegion('Hide');
  }
  else {
    clientSearchRegion('Hide');

    if (clientId != '')  {
      clientWorkFlowRegion('Show');
    }
  }
}

// Print an assessment (open Jasper PDF)
function printAssessment(pAssessmentId) {

  $('#P10_PDF_ASSESSMENT_ID').val(pAssessmentId);
  $('#P10_ACTION').val('GENERATE_PDF');

  // Submit Page (Jasper is called when page is loading to show the PDF)
  apex.submit('GENERATE_PDF');
}

// Refresh the episode history display
function refreshEpisodeHistory() {
    
  // Call AJAX process to regenerate the Episode Region HTML
  apex.server.process('refreshEpisodeHistory',
    {     
    },
    {"dataType":"text",
    "success":function(episodeHistoryHTML) { 
      $('#ASSESSMENTS').find('.episodeHistory').replaceWith(episodeHistoryHTML);
      }
    }
  );
    
}

// Create an episode and refresh the Episode History
function createEpisode() {

  var clientId = $('#P10_CLIENT_ID').val();
  var reasonForInterviewId = $('#P10_PARAM_INTERVIEW_REASON_ID').val();
  var interviewDate = $('#P10_INTERVIEW_DATE').val();
  var locationId = $('#P10_PARAM_LOCATION_ID').val();
  var episodeComment = $('#P10_EPISODE_COMMENT').val();

  if ($('#P10_DISABILITY_FLAG_0').prop('checked')) {
    var disabilityFlag = 'Y';  
  }
  else {
    var disabilityFlag = 'N';  
  }

  if ($('#P10_REFUGEE_FLAG_0').prop('checked')) {
    var refugeeFlag = 'Y';  
  }
  else {
    var refugeeFlag = 'N';  
  }

  // Call AJAX process to verify Interview Date
  apex.server.process('verifyInterviewDate',
    {"x01":interviewDate
    },
    {"dataType":"text",
    "success":function(returnString) { 

      // After date verification
	    if (returnString == 'OK') {
		  
        // Reset and close the modal
        $('#P10_PARAM_INTERVIEW_REASON_ID').val('');
        $('#P10_EPISODE_COMMENT').val('');
        $('#P10_INTERVIEW_DATE').val('');
        $('#P10_PARAM_LOCATION_ID').val('');
        $('#P10_REFUGEE_FLAG_0').prop('checked', false);
        $('#P10_DISABILITY_FLAG_0').prop('checked', false);

        enableDisableCreateEpisode();
        closeModal('createEpisodeDialog');
		  
        // Call AJAX process to create episode
        apex.server.process('createEpisode',
          {"x01":clientId,
           "x02":reasonForInterviewId,
           "x03":interviewDate,
           "x04":locationId,
           "x05":disabilityFlag,
           "x06":refugeeFlag,
           "x07":episodeComment     
          },
          {"dataType":"text",
          "success":function(returnString) { 
            // After episode created - update the display
            refreshEpisodeHistory();
            }
          }
        );
		  
	    }
	    else {
        // Display error if the date is invalid
	      apex.message.alert(returnString);	  
	    }
      
    }
  }
  );
    
}

// Enable / Disable Create episode button
function enableDisableCreateEpisode() {

  var reasonForInterviewId = $('#P10_PARAM_INTERVIEW_REASON_ID').val();
  var interviewDate = $('#P10_INTERVIEW_DATE').val();
  var locationId = $('#P10_PARAM_LOCATION_ID').val();
  
  if (reasonForInterviewId == '' || interviewDate == '' || locationId == '') {
    $('#CREATE_EPISODE').prop('disabled', true);
    $('#CREATE_EPISODE').prop('title', 'Must select an interview reason before you can create episode');
  }
  else {
    $('#CREATE_EPISODE').prop('disabled', false);
    $('#CREATE_EPISODE').prop('title', '');
  }
    
}

// Skip an assessment
function skipForm(pAssessmentId) {
    
  apex.server.process('skipAssessment',
    {"x01":pAssessmentId
    },
    {"dataType":"text",
    "success":function(returnString) { 
      $.event.trigger('refreshClientWorkflow');    
    }
    }
    );
    
}
