--
-- Populate assessment override status lookup values
--
declare
  l_pg_id     number;
begin
  if yjat_utility_pkg.get_parameter_group_id('ASSESSMENT_OVERRIDE_STATUS') is null then
    insert into parameter_group
      (name,description)
    values
      ('ASSESSMENT_OVERRIDE_STATUS', 'Assessment Override Status')
    returning parameter_group_id into l_pg_id;
    
    if yjat_utility_pkg.get_parameter_id(l_pg_id, null, 'Requested') is null then
      insert into parameter
        (parameter_group_id, name, description, value, order_seq, effective_from)
      values
        (l_pg_id, 'Requested', 'Override Status Requested', 'Requested', 10, to_date('01/08/2018', 'dd/mm/yyyy'));
    end if;
    
    if yjat_utility_pkg.get_parameter_id(l_pg_id, null, 'Endorsed') is null then
      insert into parameter
        (parameter_group_id, name, description, value, order_seq, effective_from)
      values
        (l_pg_id, 'Endorsed', 'Override Status Endorsed', 'Endorsed', 20, to_date('01/08/2018', 'dd/mm/yyyy'));
    end if;
    
    if yjat_utility_pkg.get_parameter_id(l_pg_id, null, 'Approved') is null then
      insert into parameter
        (parameter_group_id, name, description, value, order_seq, effective_from)
      values
        (l_pg_id, 'Approved', 'Override Status Approved', 'Approved', 30, to_date('01/08/2018', 'dd/mm/yyyy'));
    end if;
  end if;
end;
/