/*******************************************************************************
*  YJAT - Page 25 JavaScript
*******************************************************************************/

// global variables
  var questionArray = [];
  var answerArray = [];


// Update both score and rating when required
function updateScoreAndRating() {
  calculateProgress();  
  calculateRating();
}

// Show particular form section (hide other sections) or show all (passed -1)
function showSection(pThis, pSectionId) {

  // Set the filter button to show which is active
  $('.sectionFilterButton').removeClass('filterActive');    
  $(pThis).addClass('filterActive');  
    
  // Go through all section headers and questionAnswerContainers and hide/show 
  $('.youngPerson, .sectionName, .questionAnswerContainer').each(function() {
  
    if ($(this).hasClass('formSection' + pSectionId) || pSectionId == -1 || (pSectionId == -2 && $(this).hasClass('youngPerson'))) {
	    $(this).show();
	  }
	  else {
	    $(this).hide();
	  }
  
  });
  
  // Display the start of the region
  $('html,body').animate({scrollTop:0},0);    
}

// Set pill button as selected
function setPillButtonOn(pThis) {

  // If item is readOnly ignore the click
  if ($(pThis).hasClass('pillReadOnly'))
      return;
    
  // Remove selected class from other buttons, set current one to selected
  $(pThis).closest('.pillGroup').find('.pillSelected').removeClass('pillSelected');
  $(pThis).addClass('pillSelected');
  
  // Set hidden item to the current item text
  var selectedValue = $(pThis).attr('data-answer_id');
  $(pThis).closest('div.pillGroup').find('input:first').val(selectedValue);
    
  var currentDate = new Date();  
  $('#P25_PAGE_CHANGED').val(currentDate.toString());
  
  updateScoreAndRating();
    
}  

// Calculate current Progress
function calculateProgress() {
  
  var totalDone      = 0;  
  var totalQuestions = 0;
    
  $('input[name="f03"]').not('.noAnswerExpected').not('.noAnswerRequired').each(function() {
  
    totalQuestions++;  
      
    if ($(this).val() != '') {
      totalDone++;  
    }
  });

  var percentDone = (totalDone / totalQuestions) * 100;

  $("#P25_PROGRESS").val(totalDone + ' / ' + totalQuestions + ' completed');
  $("#P25_PROGRESS_BAR_CONTAINER").find(".progressBar").css('width', percentDone + '%');
    
}

//Enables the save button if all the questions have been answered
function enableSaveButton(pAnswerArray) {

   var empties = pAnswerArray.length - pAnswerArray.filter(String).length;
    
  if (empties==0){
      $("#saveButton").addClass('t-Button--hot').prop('disabled', false).removeClass('apex_disabled');
      $('#saveButton').find('.t-Button-label').html('Save Form');
  } 
}

// Calculate rating based on questions/answers
function calculateRating() {

  //initialize global variables
  questionArray  = [];
  answerArray    = [];

  //create array of only required questions and answers
  $('input[name="f03"]').not('.noAnswerExpected').not('.noAnswerRequired').each(function() {  
      answerArray.push($(this).val());
      var $currentRow = $(this).closest('.questionAnswerRow'); 
      questionArray.push($currentRow.find('input[name="f01"]:first').val()); 
   });
    
  enableSaveButton(answerArray);
    
  // Call AJAX process to calculate
  apex.server.process('callCalculateRating',
    {"f01":questionArray,
     "f02":answerArray
    },
    {"dataType":"text",
    "success":function(returnRatingJSON) { 
      var ratingObject = JSON.parse(returnRatingJSON);   
      updateRating(ratingObject.rating, ratingObject.note);
      }
    }
  );
}

// Update the rating on the page    
function updateRating(pRating, pRatingNote) {
  $('#P25_RATING').val(pRating);    
  $('#P25_RATING_NOTE').val(pRatingNote);        
}

// Toggle display of Help Text
function hideShowHelp(pThis) {

  $helpSection = $(pThis).next('div.helpTextBox');
  $helpTitle   = $(pThis).find('span.helpTextTitle');
  $helpIcon    = $(pThis).find('span.helpTextIcon');
  
  // Expand helptext
  if ($helpSection.hasClass('helpTextClosed')) {
	  $helpSection.removeClass('helpTextClosed');
	  $helpTitle.text('Hide Question Help');
    $helpIcon.addClass('helpTextIconOpen');
  }
  // Hide helptext
  else {
	  $helpSection.addClass('helpTextClosed');
    $helpTitle.text('View Question Help');
    $helpIcon.removeClass('helpTextIconOpen');
  }	
}

// Toggle button on / off
function toggleButton(pThis, pAnswerId) {
  $(pThis).toggleClass('toggleOn');

  var $currentGroup = $(pThis).closest('.questionAnswerGroup');
  var $answer =  $currentGroup.find('input[name="f03"]:first');  
  if ($(pThis).hasClass('toggleOn')) {
      
    $(pThis).prev('input').val(pAnswerId);
      
    // Disable / grey out section & remove values
    $currentGroup.find('.indentIcon, .questionText:not(:first), .questionReference:not(:first)').addClass('disabledQuestion');  
    $currentGroup.find('.pillGroup, .commentBox, .questionExtras, div.checkBoxOmit').hide();
    //clear answers
    $currentGroup.find('.pillButton').removeClass('pillSelected'); 
    //pill buttons are not requierd, but, if selected, they need to be counted. Adding "-ignore" (instead or removing the class) provides a way to restore the state
    if ($answer.hasClass("noAnswerRequired")) {
        $answer.removeClass("noAnswerRequired").addClass("noAnswerRequired-ignore");
    }    
    $currentGroup.find('input[name="f03"]:not(:first)').addClass('noAnswerExpected').val('');
    //clear extras fields
    $currentGroup.find('input[name="f04"]').val('');  
    $currentGroup.find('input[name="f05"]').val('');  
    $currentGroup.find('input[name="f06"]').val('');  
    $currentGroup.find('.checkBox').prop('checked', false);    
    $currentGroup.find('.commentBox').val('');  
    //set the answerable state
    $currentGroup.find('input[name="f07"]:not(:first)').val('N');    

  }
  else {
      
    $(pThis).prev('input').val('');    
      
    // Enable / remove grey out
    $currentGroup.find('.indentIcon, .questionText, .questionReference').removeClass('disabledQuestion');  
    $currentGroup.find('.pillGroup, .commentBox, .questionExtras, div.checkBoxOmit').show();  
    $currentGroup.find('input[name="f03"]:not(:first)').removeClass('noAnswerExpected');   
    //set the answerable state
    $currentGroup.find('input[name="f07"]:not(:first)').val('Y');    
    if ($answer.hasClass("noAnswerRequired-ignore")) {
        $answer.removeClass("noAnswerRequired-ignore").addClass("noAnswerRequired");
    }        
  }
 
  updateScoreAndRating();   
    
}

// Turn a checkbox off (omit)
function checkBoxOff(pThis) {
  var $checkBoxDiv = $(pThis).closest('div.checkBoxOmit');
  $checkBoxDiv.find('input[name="f03"]').val(''); 
  $checkBoxDiv.find('input[type="checkbox"]').prop('checked', false);   
    
  updateScoreAndRating();
}

// Handle a checkbox click
function checkBoxClick(pThis, pAnswerId) {
    
  var $checkBoxDiv = $(pThis).closest('div.checkBoxOmit');    

  if ($(pThis).prop('checked')) {
    $checkBoxDiv.find('input[name="f03"]').val(pAnswerId);
  }
  else {
    $checkBoxDiv.find('input[name="f03"]').val('');      
  }
    
  updateScoreAndRating();
}

// Set Answer for Question
function setValue(pQuestionId, pAnswerId, pFlag) {
    
  var sel = '#qa' + pQuestionId + '-' + pAnswerId ;
  $(sel).click();
}

// Disable Question/Flag
function setReadonly(pQuestionId, pAnswerId, pFlag) {
    var sel; 
    //get question based on name and value
    if (pFlag == null || pFlag.length == 0) {
    
        sel = 'input[name="f01"][value=' + pQuestionId + ']';    
        var $qRow = $(sel).closest('.questionAnswerRow');
            // Disable / grey out row
        $qRow.find('.indentIcon, .questionText, .questionReference').addClass('disabledQuestion');  
        $qRow.find('.pillGroup, .commentBox, .questionExtras, div.checkBoxOmit').hide();
        //clear answers
        $qRow.find('.pillButton').removeClass('pillSelected');  
        $qRow.find('input[name="f03"]').addClass('noAnswerExpected').val('');
        //clear extras fields
        $qRow.find('input[name="f04"]').val('');  
        $qRow.find('input[name="f05"]').val('');  
        $qRow.find('input[name="f06"]').val('');  
        $qRow.find('.checkBox').prop('checked', false);    
        $qRow.find('.commentBox').val('');  
        //set the answerable state
        $qRow.find('input[name="f07"]').val('N');  
        
        updateScoreAndRating(); 
        
    } else {
        if (pFlag === 'S') { //disable strength checkbox
           sel = '#qa' + pQuestionId + '-s'; 
           $(sel).attr("disabled", true); //disable checkbox
           $(sel).prop('checked', false); //uncheck checkbox 
           syncVal($(sel)); //sync the value to the hidden item
           $(sel).prev().addClass("disabledQuestion"); //gray out label 
        }    
    }     
}

// Enable Question/Flag
function undoReadonly(pQuestionId, pFlag) {
    var sel; 
    
    //get question based on name and value
    if (pFlag == null || pFlag.length == 0) {
    
        sel = 'input[name="f01"][value=' + pQuestionId + ']';    
        var $qRow = $(sel).closest('.questionAnswerRow');
        // Enable row
        $qRow.find('.indentIcon, .questionText, .questionReference').removeClass('disabledQuestion');  
        $qRow.find('.pillGroup, .commentBox, .questionExtras, div.checkBoxOmit').show();        
        //set the answerable state
        $qRow.find('input[name="f03"]').removeClass('noAnswerExpected');
        $qRow.find('input[name="f07"]').val('Y');  
        
        updateScoreAndRating();
        
    } else {
        if (pFlag === 'S') { //disable strength checkbox
           sel = '#qa' + pQuestionId + '-s'; 
           $(sel).attr("disabled", false); //enable checkbox
           $(sel).prev().removeClass("disabledQuestion"); //gray out label 
        }    
    }     
    
}


// Handle an extras field change 
function syncVal(pThis) {
    
  var idHidden = '#' + $(pThis).attr('id') + 'h';
    
  //set value of corresponding hidden item  
  $(idHidden).val($(pThis).val());
  
  //handle the checkbox
  if ($(pThis).is(':checkbox')) {
      if ($(pThis).prop('checked')) {
        $(idHidden).val('Y');
      }
      else {
        $(idHidden).val('');      
      }
  }     
    
}

//Test if the action should enable any questions/flags
function scanReadonly(pString) {
       
    var jStr = pString.replace(/~/g, '"');
    var json = jQuery.parseJSON(jStr);
    for (var i in json) {
      var bool = false;  
      //test if any of the conditions are true  
      for (var j in json[i].ca) {
          var idx = questionArray.indexOf(json[i].ca[j].q.toString()); 
          var ans = answerArray[idx];
          //build the outcome. Compare the answers.
          bool = bool || (ans == parseInt(json[i].ca[j].a))                  
      }    
        //enable the json[i].q question if none of the conditions are met
        if (!bool) {
            undoReadonly(json[i].q, json[i].f);
        }
    }
    
}

// Save Form Data with warning if conditions are met
var saveFormData = function () {

  apex.server.process('customWarning',
    {},
    {"dataType":"json",
     "success":function(plj) {
       var parentId;
       var childIds = [];
       var noCount = 0;
       plj.result.forEach(function(row) {
         if (row.question_reference == '41.') { // Parent is question "41."
           parentId = 'qa'+row.question_id+'-'+row.answer_id;
         }
         else {
           childIds.push('qa'+row.question_id+'-'+row.answer_id);
         }
       });
       
       // Got element IDs needed. Count how many "No" answers.
       if ( $('[id='+parentId+']').hasClass('pillSelected') ) {
         childIds.forEach(function(cid) {
           if ( $('[id='+cid+']').hasClass('pillSelected') ) {
             noCount += 1;
           }
         });
       }
       //console.log('noCount:'+noCount+'|# of children:'+childIds.length);
       //if (noCount == childIds.length) { // Trigger warning when all child answers are "No"
       if (noCount < 2) { // Trigger warning when less than 2 answers
         var warningMsg = 'Question <strong>41.</strong> Need at least one "Yes" for either a), b), c), or d)!';
         apex.message.clearErrors();
         apex.message.showErrors([{
           type     : "error",
           location : "page",
           message  : warningMsg,
           unsafe   : false
         }]);
       }
       else {
         $("#saveButton").prop('disabled', true);
         //setTimeout(function(){
         //  $("#saveButton").prop('disabled', false);
         //}, 2000);
         apex.submit({request:'SAVE',validate:true});
         $("#saveButton").prop('disabled', false);
       }
     }
    }
  );

}


var getWarning = function() {

  var parentCt = 0;
  var childCt = 0;
  
  var ajx = function() {
    return apex.server.process('calcWarning',{});
  }
  
  ajx().then(function(data) {
    data.result.forEach(function(row) {
      if ( $('[id='+row.dom_id+']').hasClass('pillSelected') ) {
        if ( row.level == 1 ) {
          parentCt += 1;
        }
        else if ( row.level == 2) {
          childCt += 1;
        }
      }
    });
    console.log('parentCt:'+parentCt+'|'+'childCt:'+childCt);
    if (parentCt > 0 && childCt < 1) { // Parent is answered but none of the child is
      console.log('trigger warning');
    }
    else {
      console.log('ok');
    }
  },'Something went wrong'); // ajx().then
  
} // getWarning