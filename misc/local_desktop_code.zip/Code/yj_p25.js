/*******************************************************************
*  YJAT - Page 25 JavaScript
*******************************************************************/

// Global variables
var questionArray = [];
var answerArray = [];
// Global to Disable form scoring (during form load for example to stop lots of AJAX calls)
var gEnableScoring = true;

// Update both score and rating when required
function updateScoreAndRating() {
    
  if (gEnableScoring) {
    calculateProgress();  
    calculateRating();
  }
}

// Show particular form section (hide other sections) or show all (passed -1)
function showSection(pThis, pSectionId) {

  // Set the filter button to show which is active
  $('.sectionFilterButton').removeClass('filterActive');    
  $(pThis).addClass('filterActive');  
    
  // Go through all section headers and questionAnswerContainers and hide/show 
  $('.youngPerson, .sectionName, .questionAnswerContainer').each(function() {
  
    if ($(this).hasClass('formSection' + pSectionId) || pSectionId == -1 || (pSectionId == -2 && $(this).hasClass('youngPerson'))) {
      $(this).show();
    }
    else {
      $(this).hide();
    }
  
  });
  
  // Display the start of the region
  $('html,body').animate({scrollTop:0},0);    
}


// Set pill button as selected
function setPillButtonOn(pThis) {
    
      // Remove selected class from other buttons, set current one to selected
      $(pThis).closest('.pillGroup').find('.pillSelected').removeClass('pillSelected');
      $(pThis).addClass('pillSelected');

      // Set hidden item to the current item text
      var selectedValue = $(pThis).attr('data-answer_id');
      $(pThis).closest('div.pillGroup').find('input:first').val(selectedValue);
     
}  


// Set pill button as unselected
function setPillButtonOff(pThis) {

    if ($(pThis).hasClass('pillSelected')) {  
               
        $(pThis).removeClass('pillSelected');
        //clear value
        $(pThis).closest('div.pillGroup').find('input:first').val('');
    }    
          
}

// Set or unset pill button 
function togglePillButton(pThis) {
    
  // If item is readOnly ignore the click
  if ($(pThis).hasClass('pillReadOnly'))
      return;

  // If item is already selected unselect
  if ($(pThis).hasClass('pillSelected')) {
  
      setPillButtonOff(pThis);  //backout the un-click functionality 
      
  } else {    
    
      setPillButtonOn(pThis);
  }  
  var currentDate = new Date();  
  $('#P25_PAGE_CHANGED').val(currentDate.toString());
  
  updateScoreAndRating();
    
}

// Calculate current Progress
function calculateProgress() {
  
  var totalDone      = 0;  
  var totalQuestions = 0;
    
  $('input[name="f03"]').not('.noAnswerExpected').not('.noAnswerRequired').each(function() {
  
    totalQuestions++;  
      
    if ($(this).val() != '') {
      totalDone++;  
    }
  });

  var percentDone = (totalDone / totalQuestions) * 100;

  $("#P25_PROGRESS").val(totalDone + ' / ' + totalQuestions + ' completed');
  $("#P25_PROGRESS_BAR_CONTAINER").find(".progressBar").css('width', percentDone + '%');
    
}

// Enables the save button if all the questions have been answered
function enableSaveButton(pAnswerArray) {

   var empties = pAnswerArray.length - pAnswerArray.filter(String).length;
    
  if (empties==0){
      $("#saveButton").addClass('t-Button--hot').prop('disabled', false).removeClass('apex_disabled');
      $('#saveButton').find('.t-Button-label').html('Save Form');
  } 
}

//Populate Q and A Arrays
function populateArrays() {
  //initialize global variables
  questionArray  = [];
  answerArray    = [];

  //create array of only required questions and answers
  $('input[name="f03"]').not('.noAnswerExpected').not('.noAnswerRequired').each(function() {  
      answerArray.push($(this).val());
      var $currentRow = $(this).closest('.questionAnswerRow'); 
      questionArray.push($currentRow.find('input[name="f01"]:first').val()); 
   }); 
    
}

// Calculate rating based on questions/answers
function calculateRating() {

  populateArrays();
    
  enableSaveButton(answerArray);
    
  // Call AJAX process to calculate
  apex.server.process('callCalculateRating',
    {"f01":questionArray,
     "f02":answerArray
    },
    {"dataType":"text",
    "success":function(returnRatingJSON) { 
      var ratingObject = JSON.parse(returnRatingJSON);   
      updateRating(ratingObject.rating, ratingObject.note, ratingObject.score);
      }
    }
  );
}

// Update the rating on the page    
function updateRating(pRating, pRatingNote, pScore) {
    
      $('#P25_RATING').val(pRating); 
      $('#P25_RATING_NOTE').val(pRatingNote);     
      if ($('#P25_USER_ROLES').val().indexOf('SYSTEM') !== -1) {
         $('#P25_RATING').attr('title', pScore); 
      }    
}

// Toggle display of Help Text
function hideShowHelp(pThis) {

  $helpSection = $(pThis).next('div.helpTextBox');
  $helpTitle   = $(pThis).find('span.helpTextTitle');
  $helpIcon    = $(pThis).find('span.helpTextIcon');
  
  // Expand helptext
  if ($helpSection.hasClass('helpTextClosed')) {
    $helpSection.removeClass('helpTextClosed');
    $helpTitle.text('Hide Question Help');
    $helpIcon.addClass('helpTextIconOpen');
  }
  // Hide helptext
  else {
    $helpSection.addClass('helpTextClosed');
    $helpTitle.text('View Question Help');
    $helpIcon.removeClass('helpTextIconOpen');
  }
}

// Toggle button on / off
function toggleButton(pThis, pAnswerId) {
  $(pThis).toggleClass('toggleOn');

  var $currentGroup = $(pThis).closest('.questionAnswerGroup');
  var $answer =  $currentGroup.find('input[name="f03"]:first');  
  if ($(pThis).hasClass('toggleOn')) {
      
    $(pThis).prev('input').val(pAnswerId);
      
    // Disable / grey out section & remove values
    $currentGroup.find('.indentIcon, .questionText:not(:first), .questionReference:not(:first)').addClass('disabledQuestion');  
    $currentGroup.find('.pillGroup, .commentBox, .commentField, .questionExtras, div.checkBoxOmit').hide();
    //clear answers
    $currentGroup.find('.pillButton').removeClass('pillSelected'); 
    //pill buttons are not requierd, but, if selected, they need to be counted. Adding "-ignore" (instead or removing the class) provides a way to restore the state
    if ($answer.hasClass("noAnswerRequired")) {
        $answer.removeClass("noAnswerRequired").addClass("noAnswerRequired-ignore");
    }    
    $currentGroup.find('input[name="f03"]:not(:first)').addClass('noAnswerExpected').val('');
    //clear extras fields
    $currentGroup.find('input[name="f04"]').val('');  
    $currentGroup.find('input[name="f05"]').val('');  
    $currentGroup.find('input[name="f06"]').val('');  
    $currentGroup.find('input[name="f08"]').val('');  
    $currentGroup.find('.checkBox').prop('checked', false);    
    $currentGroup.find('.commentBox, .commentField').val('');  
    //set the answerable state
    $currentGroup.find('input[name="f07"]:not(:first)').val('N');    

  }
  else {
      
    $(pThis).prev('input').val('');    
      
    // Enable / remove grey out
    $currentGroup.find('.indentIcon, .questionText, .questionReference').removeClass('disabledQuestion');  
    $currentGroup.find('.pillGroup, .commentBox, .commentField, .questionExtras, div.checkBoxOmit').show();  
    $currentGroup.find('input[name="f03"]:not(:first)').removeClass('noAnswerExpected');   
    //set the answerable state
    $currentGroup.find('input[name="f07"]:not(:first)').val('Y');    
    if ($answer.hasClass("noAnswerRequired-ignore")) {
        $answer.removeClass("noAnswerRequired-ignore").addClass("noAnswerRequired");
    }        
  }
 
  updateScoreAndRating();   
    
}

// Turn a checkbox off (omit)
function checkBoxOff(pThis) {
  var $checkBoxDiv = $(pThis).closest('div.checkBoxOmit');
  $checkBoxDiv.find('input[name="f03"]').val(''); 
  $checkBoxDiv.find('input[type="checkbox"]').prop('checked', false);   
    
  updateScoreAndRating();
}

// Handle a checkbox click
function checkBoxClick(pThis, pAnswerId) {
    
  var $checkBoxDiv = $(pThis).closest('div.checkBoxOmit');    

  if ($(pThis).prop('checked')) {
    $checkBoxDiv.find('input[name="f03"]').val(pAnswerId);
  }
  else {
    $checkBoxDiv.find('input[name="f03"]').val('');      
  }
    
  updateScoreAndRating();
}

// Set Answer for Question
function setValue(pQuestionId, pAnswerId, pFlag) {
    
  var sel = '#qa' + pQuestionId + '-' + pAnswerId ;
  $(sel).click();
}

// Disable Question/Flag
function setReadonly(pQuestionId, pAnswerId, pFlag, pUpdateScore) {
  
    var sel; 
    
    if (pUpdateScore === undefined || pUpdateScore) {
      var updateScore = true;
    }
    else {
      var updateScore = false;
    }
    
    //get question based on name and value
    if (pFlag == null || pFlag.length == 0) {
    
        sel = 'input[name="f01"][value=' + pQuestionId + ']';    
        var $qRow = $(sel).closest('.questionAnswerRow');
            // Disable / grey out row
        $qRow.find('.indentIcon, .questionText, .questionReference').addClass('disabledQuestion');  
        $qRow.find('.pillGroup, .commentBox, .commentField, .questionExtras, div.checkBoxOmit').hide();
        //clear answers
        $qRow.find('.pillButton').removeClass('pillSelected');  
        $qRow.find('input[name="f03"]').addClass('noAnswerExpected').val('');
        //clear extras fields
        $qRow.find('input[name="f04"]').val('');  
        $qRow.find('input[name="f05"]').val('');  
        $qRow.find('input[name="f06"]').val('');  
        $qRow.find('input[name="f08"]').val('');  
        $qRow.find('.checkBox').prop('checked', false);    
        $qRow.find('.commentBox, .commentField').val('');  
        //set the answerable state
        $qRow.find('input[name="f07"]').val('N');  
        
        if (updateScore) {
          updateScoreAndRating(); 
        }
        
    } else {
        if (pFlag === 'S') { //disable strength checkbox
           sel = '#qa' + pQuestionId + '-s'; 
           $(sel).attr("disabled", true); //disable checkbox
           $(sel).prop('checked', false); //uncheck checkbox 
           syncVal($(sel)); //sync the value to the hidden item
           $(sel).prev().addClass("disabledQuestion"); //gray out label 
        }    
    }     
}

// Enable Question/Flag
function undoReadonly(pQuestionId, pFlag) {
    var sel; 
    
    //get question based on name and value
    if (pFlag == null || pFlag.length == 0) {
    
        sel = 'input[name="f01"][value=' + pQuestionId + ']';    
        var $qRow = $(sel).closest('.questionAnswerRow');
        // Enable row
        $qRow.find('.indentIcon, .questionText, .questionReference').removeClass('disabledQuestion');  
        $qRow.find('.pillGroup, .commentBox, .commentField, .questionExtras, div.checkBoxOmit').show();        
        //set the answerable state
        $qRow.find('input[name="f03"]').removeClass('noAnswerExpected');
        $qRow.find('input[name="f07"]').val('Y');  
        
        updateScoreAndRating();
        
    } else {
        if (pFlag === 'S') { //disable strength checkbox
           sel = '#qa' + pQuestionId + '-s'; 
           $(sel).attr("disabled", false); //enable checkbox
           $(sel).prev().removeClass("disabledQuestion"); //gray out label 
        }    
    }     
    
}


// Handle an extras field change 
function syncVal(pThis) {
    
  var idHidden = '#' + $(pThis).attr('id') + 'h';
    
  //set value of corresponding hidden item  
  $(idHidden).val($(pThis).val());
  
  //handle the checkbox
  if ($(pThis).is(':checkbox')) {
      if ($(pThis).prop('checked')) {
        $(idHidden).val('Y');
      }
      else {
        $(idHidden).val('');      
      }
  }     
    
}

//Test if the action should enable any questions/flags
function scanReadonly(pString) {
       
    var jStr = pString.replace(/~/g, '"');
    var json = jQuery.parseJSON(jStr);
    for (var i in json) {
      var bool = false;  
      //test if any of the conditions are true  
      for (var j in json[i].ca) {
          var idx = questionArray.indexOf(json[i].ca[j].q.toString()); 
          var ans = answerArray[idx];
          //build the outcome. Compare the answers.
          bool = bool || (ans == parseInt(json[i].ca[j].a))                  
      }    
      //enable the json[i].q question if none of the conditions are met
      if (!bool) {
            undoReadonly(json[i].q, json[i].f);
      } else {
            setReadonly(json[i].q, null, json[i].f, true)
      }
    }
    
}

//Test if the action should enable any questions/flags
function checkRelationships(pString) {
    
    populateArrays();
    
    var jStr = pString.replace(/~/g, '"');
    var json = jQuery.parseJSON(jStr);
    for (var i in json) {
      var bool = false;  
      //test if any of the conditions are true  
      for (var j in json[i].ca) {
          var idx = questionArray.indexOf(json[i].ca[j].q.toString()); 
          var ans = answerArray[idx];
          //build the outcome. Compare the answers.
          bool = bool || (ans == parseInt(json[i].ca[j].a));
      }    

      var el = $('#qa'+json[i].q+'-'+json[i].a); 
      //set the json[i].q question to json[i].a  answer if any of the conditions are met
      if (bool) {
          //console.log("set");console.log(el);
          
         setPillButtonOn(el);
      } else { 
         //console.log("unset"); console.log(el);
         setPillButtonOff(el);  
      }  
    }
    
}


// Warn (if any) and Save form
function warnSaveForm() {
  $("#saveButton").prop('disabled', true);
  var warnings = [];
  var callback = 'warnSaveForm';
  
  // If LS Assessment (LS/RNR) Form
  if ($('#P25_FORM_CODE').val() == 'LS/RNR') {
    apex.server.process(callback,{
      'x01':$('#P25_FORM_ID').val(),  // Form ID
      'x02': '41.'                    // question_reference
    }).then(function(data) {
      var theParent;
      var validCt = 0;
      data.result.forEach(function(theResult) {
        theResult.parent_answers.forEach(function(parentAnswer) {
          if ( $('[id=' + parentAnswer.dom_id + ']').hasClass('pillSelected') && parentAnswer.score > 0) { // Parent has positive score
            theParent = parentAnswer;
          }
        });
        
        if (theParent) {
          theResult.child_questions.forEach(function(childQuestion) {
            childQuestion.child_answers.forEach(function(childAnswer) {
              if ( $('[id=' + childAnswer.dom_id + ']').hasClass('pillSelected') ) { // All children with answers
                // Weigthing points: a) is 100, b), c), d) is 1 each.
                if (childAnswer.question_reference === 'a)') {
                  validCt += 100;
                } else {
                  validCt += 1;
                }
              }
            });
          });
          // Set warning message if point's too low
          if (validCt <= 100) {
            var questionTopOffset = $('[id=questionId-' + theParent.question_id + ']').offset().top - ($('#t_Body_title').height() + 100);
            var questionUrl = '<a href="javascript:$(\'html, body\').animate({scrollTop: '+ (questionTopOffset) + '});">(show)</a>';
            warnings.push('Question 41 is Yes. Must complete item a) plus at least one of b), c), or d) ' + questionUrl);
          }
        }
      });

      return apex.server.process(callback,{
        'x01':$('#P25_FORM_ID').val(),  // Form ID
        'x02': '42.'                    // question_reference
      });
    }, 'Error: LS Question 41').then(function(data) {
      var theParent;
      var validCt = 0;
      data.result.forEach(function(theResult) {
        theResult.parent_answers.forEach(function(parentAnswer) {
          if ( $('[id=' + parentAnswer.dom_id + ']').hasClass('pillSelected') && parentAnswer.score > 0) { // Parent has positive score
            theParent = parentAnswer;
          }
        });
        
        if (theParent) {
          theResult.child_questions.forEach(function(childQuestion) {
            childQuestion.child_answers.forEach(function(childAnswer) {
              if ( $('[id=' + childAnswer.dom_id + ']').hasClass('pillSelected') ) { // All children with answers
                // Weigthing points: 1 for each child answer
                validCt += 1;
              }
            });
          });
          // Set warning message if point's too low
          if (validCt < 1) {
            var questionTopOffset = $('[id=questionId-' + theParent.question_id + ']').offset().top - ($('#t_Body_title').height() + 100);
            var questionUrl = '<a href="javascript:$(\'html, body\').animate({scrollTop: '+ (questionTopOffset) + '});">(show)</a>';
            warnings.push('Question 42 is Yes. Must complete at least one child question ' + questionUrl);
          }
        }
      });
      
      return apex.server.process(callback,{
        'x01':$('#P25_FORM_ID').val(),  // Form ID
        'x02': '43.'                    // question_reference
      });
    }, 'Error: LS Question 42').then(function(data) {
      var theParent;
      var validCt = 0;
      data.result.forEach(function(theResult) {
        theResult.parent_answers.forEach(function(parentAnswer) {
          if ( $('[id=' + parentAnswer.dom_id + ']').hasClass('pillSelected') && parentAnswer.score > 0) { // Parent has positive score
            theParent = parentAnswer;
          }
        });
        
        if (theParent) {
          theResult.child_questions.forEach(function(childQuestion) {
            childQuestion.child_answers.forEach(function(childAnswer) {
              if ( $('[id=' + childAnswer.dom_id + ']').hasClass('pillSelected') ) { // All children with answers
                // Weigthing points: 1 for each child answer
                validCt += 1;
              }
            });
          });
          // Set warning message if point's too low
          if (validCt < 4) {
            var questionTopOffset = $('[id=questionId-' + theParent.question_id + ']').offset().top - ($('#t_Body_title').height() + 100);
            var questionUrl = '<a href="javascript:$(\'html, body\').animate({scrollTop: '+ (questionTopOffset) + '});">(show)</a>';
            warnings.push('Question 43 is Yes. Must complete at least four of its child questions ' + questionUrl);
          }
        }
      });
    }, 'Error: LS Question 43').then(function(data) {
      if (warnings.length > 0) {
        // Show warning messages if any
        apex.message.clearErrors();
        warnings.forEach(function(warning) {
          apex.message.showErrors([{
            type: apex.message.TYPE.ERROR,
            location: ["page"],
            message: warning,
            unsafe: false
          }]);
        });
        // Re-enable button
        $("#saveButton").prop('disabled', false);
        return false;
      }
      // No warnings if this line is reached
      return true;
    }, 'Error: LS Show Warning').then(function(bool) {
      if (bool) {
        apex.submit({request:'SAVE',validate:true});
      }
    }, 'Error: LS Submit');
  }
  else if ($('#P25_FORM_CODE').val() == 'YLS/CMI 2.0') {
    apex.server.process(callback,{
      'x01':$('#P25_FORM_ID').val(),  // Form ID
      'x02': '5.'                     // question_reference
    }).then(function(data) {
      var mainAnswer;
      var otherAnswers = [];
      data.result.forEach(function(theResult) {
        theResult.child_questions.forEach(function(childQuestion) {
          childQuestion.child_answers.forEach(function(childAnswer) {
            if ( $('[id=' + childAnswer.dom_id + ']').hasClass('pillSelected') ) { // All children with answers
              if (childAnswer.question_reference === 'd)' && childAnswer.score > 0) { // d) is marked
                mainAnswer = childAnswer;
              }
              if ( childAnswer.question_reference === 'b)' || childAnswer.question_reference === 'c)' ) {
                otherAnswers.push(childAnswer);
              }
            }
          });
        });
      });
      if (mainAnswer) {
        var points = 0;;
        otherAnswers.forEach(function(oa) {
          points += oa.score;
        });

        if (points < 1) {
          var questionTopOffset = $('[id=questionId-' + mainAnswer.question_id + ']').offset().top - ($('#t_Body_title').height() + 500);
          var questionUrl = '<a href="javascript:$(\'html, body\').animate({scrollTop: '+ (questionTopOffset) + '});">(show)</a>';
          warnings.push('Question 5d) is selected. One of 5b) or 5c) must be marked ' + questionUrl);
        }
      }
    }, 'Error: YLS Question 5').then(function(data) {
      if (warnings.length > 0) {
        // Show warning messages if any
        apex.message.clearErrors();
        warnings.forEach(function(warning) {
          apex.message.showErrors([{
            type: apex.message.TYPE.ERROR,
            location: ["page"],
            message: warning,
            unsafe: false
          }]);
        });
        // Re-enable button
        $("#saveButton").prop('disabled', false);
        return false;
      }
      // No warnings if this line is reached
      return true;
    }, 'Error: YLS Show Warning').then(function(bool) {
      if (bool) {
        apex.submit({request:'SAVE',validate:true});
      }
    }, 'Error: YLS Submit');
  }
  // Other forms with no Warnings/ Validations
  else {
    apex.submit({request:'SAVE',validate:true});
  }
} // end of function

// Display checkboxes for questions that have JSON defining set of extra checkboxes
function renderCheckboxAnswer() {

  var pageMode = $('#P25_PAGE_MODE').val();

  // Loop over extra answer array to find JSON to render checkboxes
  $('input[name="f13"]').each(function() {
    
    var jsonString = $(this).val();
    
    if (jsonString != '') {

      var parsedObject = JSON.parse(jsonString);
      var jsonStringId = $(this).attr('id');

      for (var index = 0; index < parsedObject.checkboxArray.length; index++) {
        
        // Get elements for the current array object
        var answerText    = parsedObject.checkboxArray[index].answerText;
        var answerChecked = parsedObject.checkboxArray[index].checked;
        var answerId      = parsedObject.checkboxArray[index].answerId;
        
        if (answerChecked) {
          var currentState = 'checked';
        }
        else {
          var currentState = '';
        }

        // Different behaviour if the page is in readonly mode
        if (pageMode == 'VIEW') {
          var currentState = currentState + ' disabled';
          var functionCall = ''
        }
        else {
          var functionCall = ' onclick="toggleCheckbox(' + answerId + ',\'' + jsonStringId + '\')" ';
        }

        var checkboxString = '<label class="checkboxLabel"><input class="checkboxInput" type="checkbox" ' + functionCall + 
                             currentState + '/><div class="checkboxText">' + answerText + '</div></label>';
        
        $('#' + jsonStringId + '-display').append(checkboxString);
        
      }
      
    }
    
  });
  
}

// After a checkbox is toggled - update JSON string
function toggleCheckbox(pAnswerId, pJsonStringId) {
  
  var $jsonStringObject = $('#' + pJsonStringId);
  var jsonString = $jsonStringObject.val();
  
  var parsedObject = JSON.parse(jsonString);

  // Loop through JSON to update required checkbox state
  for (var index = 0; index < parsedObject.checkboxArray.length; index++) {

    var answerChecked = parsedObject.checkboxArray[index].checked;
    var answerId      = parsedObject.checkboxArray[index].answerId;
  
    if (answerId == pAnswerId) {
      if (answerChecked) {
        parsedObject.checkboxArray[index].checked = false;
      }
      else {
        parsedObject.checkboxArray[index].checked = true;        
      }
    }
    
  }
  
  // Convert JSON object back to a string
  $jsonStringObject.val(JSON.stringify(parsedObject));  
}