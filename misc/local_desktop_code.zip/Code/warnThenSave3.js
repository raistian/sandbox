// Warn (if any) and Save form
var warnSaveForm_upd = function() {
  $("#saveButton").prop('disabled', true);

  var messages    = [];
  var questionIds = [];
  
  // If LS Assessment (LS/RNR) Form
  if ($('#P25_FORM_CODE').val() == 'LS/RNR') {

    apex.server.process('warnQuestion41_process',{})
      .then(function(data) {
        var parentCt = 0;
        var childCt = 0;
        var parentId = '';
        // Question 41 data
        data.result.forEach(function(row) {
          if ( $('[id='+row.dom_id+']').hasClass('pillSelected') ) {
            if ( row.level == 1 && row.score > 0) { // Parent has Yes answer
              parentCt += 1;
              parentId = row.question_id;
            }
            else if ( row.level == 2 && row.question_reference != 'a)' ) {
              childCt += 1;
            }
          }
        });

        if (parentCt > 0 && childCt < 1) {
          // Set parent question ID and add warning message
          questionIds.push(parentId);
          messages.push('Question 41 is Yes. Must complete item a) plus at least one of b), c), or d)');
        }
        return apex.server.process('warnQuestion42_process',{});
      },'Error@warnQuestion41')
      .then(function(data) {
        var parentCt = 0;
        var childCt = 0;
        var parentId = '';
        // Question 42 data
        data.result.forEach(function(row) {
          if ( $('[id='+row.dom_id+']').hasClass('pillSelected') ) {
            if ( row.level == 1 && row.score > 0) { // Parent has Yes answer
              parentCt += 1;
              parentId = row.question_id;
            }
            else if ( row.level == 2) {
              childCt += 1;
            }
          }
        });

        if (parentCt > 0 && childCt < 1) {
          // Set parent question ID and add warning message
          questionIds.push(parentId);
          messages.push('Question 42 is Yes. Must complete at least one child question');
        }
        return apex.server.process('warnQuestion43_process',{});
      },'Error@warnQuestion42')
      .then(function(data) {
        var parentCt = 0;
        var childCt = 0;
        var parentId = '';
        // Question 43 data
        data.result.forEach(function(row) {
          if ( $('[id='+row.dom_id+']').hasClass('pillSelected') ) {
            if ( row.level == 1 && row.score > 0) { // Parent has Yes answer
              parentCt += 1;
              parentId = row.question_id;
            }
            else if ( row.level == 2 ) {
              childCt += 1;
            }
          }
        });

        if (parentCt > 0 && childCt < 4) {
          // Set parent question ID and add warning message
          questionIds.push(parentId);
          messages.push('Question 43 is Yes. Must complete at least four of its child questions');
        }
      },'Error@warnQuestion43')
      .then(function(data) {
        if (questionIds.length > 0) {
          apex.message.clearErrors();
          
          for (var i=0;i<messages.length;i++) {
            // The form has a top region (breadcrumb) that does not move, so we need to offset its height of approx 390px
            var offset = $('[id=questionAnswerRow-'+questionIds[i]+']').offset();
            apex.message.showErrors([{
              type: apex.message.TYPE.ERROR,
              location: ["page"],
              message: ( messages[i] + ' <a href="javascript:$(\'html, body\').animate({scrollTop: '+ (offset.top-390) + '});">(show)</a>' ),
              unsafe: false
            }]);
          }
          // There's a warning, return false.
          return false;
        }
        // No warnings, return true.
        return true;
      },'Error@showError')
      .then(function(bool) {
        if (bool) {
          apex.submit({request:'SAVE',validate:true});
        }
      },'Error@submitSave');
      
  } // end if LS Assessment Form
  // else if YLS Assessment (YLS/CMI 2.0) Form
  else if ($('#P25_FORM_CODE').val() == 'YLS/CMI 2.0') {
    apex.server.process('warnYlsQuestion5',{'x01':$('#P25_FORM_ID').val()}).then(function(data) {

      var questionId = ''; // ID of answer that drives the warning rules
      var warnings   = []; // Array of warning messages

      data.result.forEach(function(row) {
        //if ( row.level == 2 && row.question_reference == 'd)' && row.score == 1 && $('[id='+row.dom_id+']').hasClass('pillSelected') ) {
        if (row.question_reference == 'd)' && row.score == 1 && $('[id='+row.dom_id+']').hasClass('pillSelected')) {
          questionId = row.dom_id;
        }
        else if ($('[id='+row.dom_id+']').hasClass('pillSelected') && row.score == 0 && (row.question_reference == 'b)' || row.question_reference == 'c)') ) { // b or c is Omitted
          warnings.push(row.question_reference + ' must be marked');
        }
      });

      if (questionId.length > 0) {
        console.log('relevant');
        console.log(warnings.length);

      }

    });
  }
  else {
    apex.submit({request:'SAVE',validate:true});
  }
  
  // Prevents multiple submits in quick succession
  setTimeout(function(){
    $("#saveButton").prop('disabled', false);
  }, 2000);
} // end of function