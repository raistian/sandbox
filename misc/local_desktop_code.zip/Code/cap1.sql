if :request in ('CREATE','SAVE') then
  if utility_pkg.get_parameter_code(:p317_param_document_type_id) = 'SCENARIO_DOCUMENT' then
    if :p317_scenario_id is null then
      return 'Houston we have a problem';
    end if;
  end if;
end if;
return '';


-- class="clickAnywhere t-Button t-Button--hot t-Button--simple t-Button--stretch" title="Click to view File Details"

select file_name, substr(file_name, instr(file_name, '.', -1)) istr
from document;

desc common_doj.lob_pkg;

insert into test_file
  select
    id
  , application_id
  , name
  , filename
  , mime_type
  , created_on
  , blob_content
  from apex_application_temp_files
  where name = :p317_file_blob
;

-- accept=".pdf,.doc,.docx"
-- 3940585003758167/How To Set Up a Contractor Nexus Account.doc
desc apex_application_temp_files;

select * from common_doj.param_group;
select * from common_doj.application_param where application_param_id = 2609;

select * -- param_group_id=765
from common_doj.param_group
where application_id = 412
and group_key = 'QUESTION_TYPE';

select q.*
from question q
where utility_pkg.get_parameter_code(q.param_question_type_id) = 'CONFIDENCE_RATING_REVIEW';

-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
/**
 * Parameters
**/
select
  p.ordering,
  p.code,
  p.value_txt,
  p.description,
  g.group_key,
  p.application_param_id,
  g.param_group_id,
  g.application_id
from common_doj.param_group g
join common_doj.application_param p on (g.param_group_id = p.param_group_id)
where 1 = 1
and p.active_flg = 'Y'
and g.group_key = 'DOCUMENT_TYPE';
-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
/**
 * QUESTION_TYPE
 *   + CONFIDENCE_RATING_REVIEW (new parameter)
**/
declare
  l_application_id          pls_integer := 412;
  l_group_key               varchar2(255) := 'QUESTION_TYPE';
  l_param_group_id          pls_integer;
  l_application_param_id    pls_integer;
begin
  select  param_group_id
  into    l_param_group_id
  from    common_doj.param_group
  where   application_id = l_application_id
  and     group_key = l_group_key;
  
  insert into common_doj.application_param (
    param_group_id, ordering, active_flg, code, description, value_txt
  )
  values (
    l_param_group_id,                         -- param_group_id
    1,                                        -- ordering
    'Y',                                      -- active_flg
    'CONFIDENCE_RATING_REVIEW',               -- code
    'Question for Confidence Rating Review',  -- description
    'Confidence Rating Review'                -- value_txt
  )
  returning application_param_id into l_application_param_id;
  dbms_output.put_line(l_application_param_id);
end;
-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
declare
  l_application_param_id    pls_integer;
begin
  l_application_param_id := utility_pkg.get_application_param_id
    ( p_param_group_id => utility_pkg.get_param_group_id('QUESTION_TYPE'),
      p_group_key => null,
      p_code => 'CONFIDENCE_RATING_REVIEW' );
  
  insert into question (
    order_seq, param_question_type_id, question_text
  )
  values (
    70, l_application_param_id, 'Provide any additional comments on the assessment process for consideration in future assessment years.'
  );
end;
-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
/**
 * DOCUMENT_TYPE (new group)
**/
declare
  l_application_id          pls_integer := 412;
  l_group_key               varchar2(255) := 'DOCUMENT_TYPE';
  l_param_group_id          pls_integer;
  l_application_param_id    pls_integer;
begin
  insert into common_doj.param_group (
    application_id, group_key, group_name, user_editable_flg, show_columns_flg, maxlength_value, style_specified_fg
  )
  values (
    l_application_id    -- application_id
  , l_group_key         -- group_key
  , 'Document Type'     -- group_name
  , 'N'                 -- user_editable_flg
  , 'C'                 -- show_columns_flg
  , 100                 -- maxlength_value
  , 'N'                 -- style_specified_fg
  )
  returning param_group_id into l_param_group_id;
   
  insert into common_doj.application_param (
    param_group_id, ordering, active_flg, code, description, value_txt
  )
  values (
    l_param_group_id                          -- param_group_id
  , 1                                         -- ordering
  , 'Y'                                       -- active_flg
  , 'REFERENCE_DOCUMENT'                      -- code
  , 'Reference Document'                      -- description
  , 'Reference Document'                      -- value_txt
  )
  returning application_param_id into l_application_param_id;
  dbms_output.put_line(l_application_param_id);
end;
-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --
drop table test_file purge;
create table test_file (
  id                number
, application_id    number
, name              varchar2(400)
, filename          varchar2(400)
, mime_type         varchar2(255)
, created_on        date default sysdate
, blob_content      blob
);
-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- --