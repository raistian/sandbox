// Make the client search header clickable to minimize/maximize the region 
$("#CLIENT_SEARCH .t-Region-header").click(function(){ toggleClientSearch() });
$("#CLIENT_SEARCH .t-Region-header").attr('title','Click to minimize / maximize this region');

// Make enter on search fields trigger a search
$('#P10_FIRST_NAME, #P10_LAST_NAME, #P10_CAID_SEARCH').keyup(function(e) {
  if (e.keyCode == '13')
    $('#UserSearch').trigger('click');
});

// Hide client workflow section if client not selected
if ($('#P10_CLIENT_ID').val() == '') {
  clientWorkFlowRegion('Hide','SkipAnimate');
}
else {
  // Hide client search if a client is selected
  clientSearchRegion('Hide','SkipAnimate');
}

// Only show the Create Episode button if mandatory fields are filled out
$('#P10_PARAM_INTERVIEW_REASON_ID, #P10_PARAM_LOCATION_ID, #P10_INTERVIEW_DATE').on('change', function() { enableDisableCreateEpisode();});

// Limit text area type fields
restrictLength('P10_EPISODE_COMMENT', 1000, 'Episode Comments');
restrictLength('P10_OVERRIDE_REASON', 1000, 'Override Reason');
