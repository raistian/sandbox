// Move header into breadcrumb region so it stays at the top of the page
$('#INFO_HEADER').appendTo('#HEADER_DISPLAY');

// Calculate current progress indicator and rating
calculateProgress();  
calculateRating();

// Set the breadcrumb to the form name
var formName = $('#P25_FORM_DESCRIPTION').val();
$('h1.t-Breadcrumb-label').text(formName);

// Set page title to the form code
document.title = 'Form ' + $('#P25_FORM_CODE').val();

// Restrict comment fields
restrictLengthAllName('f10', 1000, 'Comments');
restrictLengthAllName('f11', 1000, 'Source of info');
