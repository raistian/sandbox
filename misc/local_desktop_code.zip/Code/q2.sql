select distinct iq.process_type
from
(
    select 
      fm.name as form_name,
      pmp.description as process_type,
      pm.value as match_type,
      fsr.number_1,
      fsr.number_2,
      fsr.number_3,
      fsr.value_text,
      pmr.value as result_type,
      fsr.result_prefix,
      fsr.result_text,
      fsr.result_suffix,
      fsr.param_sex_id,
      fsr.param_location_id,
      fsr.param_value_type_id,
      fsr.order_seq
    from 
      form_score_rule fsr
    join form fm on (fm.form_id = fsr.form_id)
    join parameter pm  on (pm.parameter_id = fsr.param_match_type_id)  
    join parameter pmp on (pmp.parameter_id = fsr.param_process_type_id)
    join parameter pmr on (pmr.parameter_id = fsr.param_result_type_id)
    where 1 = 1
    --and fm.form_id = 3
    --order by 
    --  pmp.order_seq, fsr.order_seq
) iq
;