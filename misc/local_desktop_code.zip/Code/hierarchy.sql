with
  a as ( -- episode, assessment, form
    select
      e1.episode_id,
      e1.interview_date,
      yjat_utility_pkg.get_parameter_value(e1.param_interview_reason_id) as interview_reason,
      e1.active_flag as episode_active_flag,
      a1.assessment_id,
      yjat_utility_pkg.get_parameter_value(f1.param_assessment_type_id) as assessment_type,
      a1.create_by as assessment_create_by,
      a1.update_by as assessment_update_by,
      f1.form_id,
      f1.form_code
    from
      episode e1
      left join assessment a1 on e1.episode_id = a1.episode_id
      join form f1 on a1.form_id = f1.form_id
  ),
  s as ( -- plus section
    select
      a.*,
      s1.section_id,
      s1.name as section_name,
      s1.short_name as section_short_name
    from
      section s1
      join a on s1.form_id = a.form_id
  ),
  q as ( -- plus question
    select
      s.*,
      q1.question_id,
      q1.parent_id,
      q1.answer_set_id,
      q1.order_seq,
      q1.question_reference,
      q1.question_short
    from
      question q1
      join s on q1.section_id = s.section_id
  )
select *
from q
where 1 = 1
and assessment_create_by = 'AACHRIST'
;