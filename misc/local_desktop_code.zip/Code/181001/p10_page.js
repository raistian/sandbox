/**********************************************************
* YJAT Application - Page 10 JavaScript
**********************************************************/

// Hide or show the client search region
function clientSearchRegion(pHideShow, pSkipAnimate) {
  
  var $searchRegion = $('#CLIENT_SEARCH .t-Region-bodyWrap');

  if (pSkipAnimate == 'SkipAnimate') {
    $searchRegion.addClass('noAnimate');
  }
  else {
    $searchRegion.removeClass('noAnimate');    
  }  
  
  if (pHideShow == 'Hide') {
    $searchRegion.addClass('sliderClosed');
    $('#MINMAX_BUTTON').addClass('fa-rotate-270');
  }
  else {
    $searchRegion.removeClass('sliderClosed');
    $('#MINMAX_BUTTON').removeClass('fa-rotate-270');
  }
}

// Hide or show the client workflow region
function clientWorkFlowRegion(pHideShow, pSkipAnimate) {
  
  var $workFlowRegion = $('#CLIENT_WORKFLOW .t-Region-bodyWrap');

  if (pSkipAnimate == 'SkipAnimate') {
    $workFlowRegion.addClass('noAnimate');
  }
  else {
    $workFlowRegion.removeClass('noAnimate');    
  }  

  if (pHideShow == 'Hide') {
    $workFlowRegion.addClass('sliderClosed');
  }
  else {
    $workFlowRegion.removeClass('sliderClosed');
  }
}

// Refresh the Assessment Region 
function refreshAssessmentRegion(pClientID) {

  $('#P10_CLIENT_ID').val(pClientID);

  // Shrink Client search region and adjust icon
  clientSearchRegion('Hide');

  // Call dynamic action to update page items and refresh report region
  $.event.trigger('refreshClientWorkflow');
}

// Toggle display of client search region
function toggleClientSearch() {

  var currentHideSearch = $('#CLIENT_SEARCH .t-Region-bodyWrap').hasClass('sliderClosed');
  var clientId = $('#P10_CLIENT_ID').val();

  // If search currently hidden then show it
  if (currentHideSearch) {
    clientSearchRegion('Show');
    clientWorkFlowRegion('Hide');
  }
  else {
    clientSearchRegion('Hide');

    if (clientId != '')  {
      clientWorkFlowRegion('Show');
    }
  }
}

// Print an assessment (open Jasper PDF)
function printAssessment(pAssessmentId) {

  $('#P10_PDF_ASSESSMENT_ID').val(pAssessmentId);
  $('#P10_ACTION').val('GENERATE_PDF');

  // Submit Page (Jasper is called when page is loading to show the PDF)
  apex.submit('GENERATE_PDF');
}

// Refresh the episode history display
function refreshEpisodeHistory() {
    
  // Call AJAX process to regenerate the Episode Region HTML
  apex.server.process('refreshEpisodeHistory',
    {     
    },
    {"dataType":"text",
    "success":function(episodeHistoryHTML) { 
      $('#ASSESSMENTS').find('.episodeHistory').replaceWith(episodeHistoryHTML);
      console.log('b4 episode warning');
      // AJAX Check if warning should be displayed
      apex.server.process('existingEpisodeWarning',
        {
        },
        {"dataType":"text",
        "success":function(existingEpisodes) { 
console.log('existing ' + existingEpisodes);
          if (existingEpisodes == 'Y') {
            $('#P10_WARNING_CONTAINER').closest('.row').show();  
          }
          else {
            $('#P10_WARNING_CONTAINER').closest('.row').hide();  
          }
        }
        }
      );      
    }
    }
  );  
}

// Reset the create episode fields
function resetCreateEpisode() {

  $('#P10_PARAM_INTERVIEW_REASON_ID').val('');
  $('#P10_EPISODE_COMMENT').val('');
  $('#P10_INTERVIEW_DATE').val('');
  $('#P10_PARAM_LOCATION_ID').val('');
  $('#P10_REFUGEE_FLAG_0').prop('checked', false);
  $('#P10_DISABILITY_FLAG_0').prop('checked', false);
  $('#P10_FORMS_AVAILABLE_DISPLAY').text('');

}

// Create an episode and refresh the Episode History
function createEpisode() {

  var clientId = $('#P10_CLIENT_ID').val();
  var reasonForInterviewId = $('#P10_PARAM_INTERVIEW_REASON_ID').val();
  var interviewDate = $('#P10_INTERVIEW_DATE').val();
  var locationId = $('#P10_PARAM_LOCATION_ID').val();
  var episodeComment = $('#P10_EPISODE_COMMENT').val();

  if ($('#P10_DISABILITY_FLAG_0').prop('checked')) {
    var disabilityFlag = 'Y';  
  }
  else {
    var disabilityFlag = 'N';  
  }

  if ($('#P10_REFUGEE_FLAG_0').prop('checked')) {
    var refugeeFlag = 'Y';  
  }
  else {
    var refugeeFlag = 'N';  
  }

  // Call AJAX process to verify Interview Date
  apex.server.process('verifyInterviewDate',
    {"x01":interviewDate
    },
    {"dataType":"text",
    "success":function(returnString) { 

      // After date verification
      if (returnString == 'OK') {
  
        // Reset and close the modal
        resetCreateEpisode();
        enableDisableCreateEpisode();
        closeModal('createEpisodeDialog');
      
        // Call AJAX process to create episode
        apex.server.process('createEpisode',
          {"x01":clientId,
           "x02":reasonForInterviewId,
           "x03":interviewDate,
           "x04":locationId,
           "x05":disabilityFlag,
           "x06":refugeeFlag,
           "x07":episodeComment     
          },
          {"dataType":"text",
          "success":function(returnString) { 
            // After episode created - update the display
            refreshEpisodeHistory();
            }
          }
        );
  
      }
      else {
        // Display error if the date is invalid
        apex.message.alert(returnString);   
      }
      
    }
  }
  );
    
}

// Enable / Disable Create episode button
function enableDisableCreateEpisode() {

  var reasonForInterviewId = $('#P10_PARAM_INTERVIEW_REASON_ID').val();
  var interviewDate = $('#P10_INTERVIEW_DATE').val();
  var locationId = $('#P10_PARAM_LOCATION_ID').val();
  
  if (reasonForInterviewId == '' || interviewDate == '' || locationId == '') {
    $('#CREATE_EPISODE').prop('disabled', true);
    $('#CREATE_EPISODE').prop('title', 'Must select an interview reason before you can create episode');
    $('#P10_FORMS_AVAILABLE_DISPLAY').text('');  
  }
  else {      
    $('#CREATE_EPISODE').prop('disabled', false);
    $('#CREATE_EPISODE').prop('title', '');
    lookupFormsAvailable();      
  }
    
}

// Skip an assessment
function skipForm(pAssessmentId) {
    
  apex.server.process('skipAssessment',
    {"x01":pAssessmentId
    },
    {"dataType":"text",
    "success":function(returnString) { 
      $.event.trigger('refreshClientWorkflow');    
    }
    }
    );
    
}

// Open inline-modal dialog for Override functionalities
function overrideModal(pAssessmentId) {
  // Empties APEX select-list (will be replaced with AJAX result)
  $('#P10_OVERRIDE_REQUEST').empty().attr('option');
  // Clear Override Reason
  $('#P10_OVERRIDE_REASON').val('');
  // Disable override by default since it's only available for forms with a Rating
  $('#P10_CURRENT_RATING').text('Unable to Override (rating not available).');
  
  $('#P10_OVERRIDE_REQUEST_CONTAINER').hide();
  $('#P10_OVERRIDE_REASON_CONTAINER').hide();
  $('#REQUEST_OVERRIDE').hide();
  
  openModal('overrideRatingDialog');
  
  apex.server.process('overrideAssessment',
    {"x01":pAssessmentId},
    {"dataType":"json",
     "success":function(plj) {

        $('#P10_ASSESSMENT_ID').val(pAssessmentId);

        plj.result.forEach(function(row) {
          if (row.current_rating_flag == 'Y') {
            $('#P10_CURRENT_RATING').text(row.result_text);

            // Set override ratings when there was no previous request
            if (row.override_status == '~') {

              // Set allowed PREVIOUS Rating
              if (row.prev_result_text != '~') {
                $('#P10_OVERRIDE_REQUEST').append($('<option></option>').attr('value', row.prev_result_text).text(row.prev_result_text));
              }
              // Set allowed NEXT Rating
              if (row.next_result_text != '~') {
                $('#P10_OVERRIDE_REQUEST').append($('<option></option>').attr('value', row.next_result_text).text(row.next_result_text));
              }
              
              // Show items
              $('#P10_OVERRIDE_REQUEST_CONTAINER').show();
              $('#P10_OVERRIDE_REASON_CONTAINER').show();
              $('#REQUEST_OVERRIDE').show();

            } else { // There is an existing override request
            
              var ratingText;
              if (row.override_status == 'Approved') {
                // Request is approved, use the new rating
                ratingText = row.override_requested_rating + " (Overriden)";
              } else {
                // Request not yet approved, show progress status ie. "Requested", "Endorsed"
                ratingText = row.result_text + " >> " + row.override_requested_rating + " (" + row.override_status + ")";
                $('#P10_OVERRIDE_REQUEST').append($('<option></option>').attr('value', row.override_requested_rating).text(row.override_requested_rating));
                $('#P10_OVERRIDE_REQUEST_CONTAINER').show();
              }
              $('#P10_CURRENT_RATING').text(ratingText);
              
              $('#P10_OVERRIDE_REASON').val(row.override_reason);
              $('#P10_OVERRIDE_REASON_CONTAINER').show();
              $('#REQUEST_OVERRIDE').hide();
              
            }
          }
        });

      }
    }
  );
}

// Save Override Request
function overrideAssessment_Request() {
  apex.server.process('overrideAssessment_Request',
    {"x01":$('#P10_ASSESSMENT_ID').val(),
     "x02":$('#P10_OVERRIDE_REQUEST').val(),
     "x03":$('#P10_OVERRIDE_REASON').val()
    },
    {"dataType":"json",
     "success":function(j) {
        if (j.success) {          
          closeModal('overrideRatingDialog');
          refreshEpisodeHistory();
        }
      }
    }
  );
}

// Delete an episode
function deleteEpisode(pEpisodeId) {

  apex.message.confirm( "Are you sure you want to delete this episode?", function( okPressed ) { 
    if (okPressed) {

      apex.server.process('deleteEpisode',
        {"x01":pEpisodeId
        },
        {"dataType":"text",
        "success":function(returnString) { 
          $.event.trigger('refreshClientWorkflow');    
          }
        }
     );
   
    }
  });    
}

// Lookup forms available
function lookupFormsAvailable() {

  var clientId = $('#P10_CLIENT_ID').val();
  var reasonForInterviewId = $('#P10_PARAM_INTERVIEW_REASON_ID').val();
  var interviewDate = $('#P10_INTERVIEW_DATE').val();
  var locationId = $('#P10_PARAM_LOCATION_ID').val();

  if ($('#P10_DISABILITY_FLAG_0').prop('checked')) {
    var disabilityFlag = 'Y';  
  }
  else {
    var disabilityFlag = 'N';  
  }
  
  // Call AJAX process to lookup forms available
  apex.server.process('formsAvailable',
    {"x01":clientId,
     "x02":reasonForInterviewId,
     "x03":interviewDate,
     "x04":locationId,
     "x05":disabilityFlag  
    },
    {"dataType":"text",
    "success":function(returnString) { 
      // After lookup - update the display
      $('#P10_FORMS_AVAILABLE_DISPLAY').text(returnString);    
      }
    }
    );
    
}
