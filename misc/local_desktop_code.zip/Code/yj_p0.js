<script type="text/javascript">
/*************************************************************************
*  YJAT - Page 0 - Common Javascript functions
*************************************************************************/

// Move the row up
function moveRowUp(pThis, pSortArrayName) {

  var $thisRow = $(pThis).closest('tr');
  var $prevRow = $thisRow.prev('tr');
  var sortItemSelector = 'input[name="' + pSortArrayName + '"]';
  
  if ($prevRow.length > 0 && $prevRow.find('td').length > 0) {
    
    // Get previous rows order id
    prevOrderNumber = $prevRow.find(sortItemSelector).val();
    thisOrderNumber = $thisRow.find(sortItemSelector).val();
    
    // Swap with previous row
    $prevRow.find(sortItemSelector).val(thisOrderNumber);
    $thisRow.find(sortItemSelector).val(prevOrderNumber);
    
    // Cut current row, move it before previous row
    $thisRow.hide();
    $copyRow = $thisRow.clone();  
    $thisRow.remove();
    $prevRow.before($copyRow);
    $prevRow.prev().fadeIn();
    
  }
}

// Move the row down
function moveRowDown(pThis, pSortArrayName) {
  
  var $thisRow = $(pThis).closest('tr');
  var $nextRow = $thisRow.next('tr');
  var sortItemSelector = 'input[name="' + pSortArrayName + '"]';
  
  if ($nextRow.length > 0 && $nextRow.find('td').length > 0) {

    // Get next rows order id
    nextOrderNumber = $nextRow.find(sortItemSelector).val();
    thisOrderNumber = $thisRow.find(sortItemSelector).val();
    
    // Swap with next row
    $nextRow.find(sortItemSelector).val(thisOrderNumber);
    $thisRow.find(sortItemSelector).val(nextOrderNumber);
    
    // Cut current row, move it after next row
    $thisRow.hide();
    $copyRow = $thisRow.clone();  
    $thisRow.remove();
    $nextRow.after($copyRow);
    $nextRow.next().fadeIn();
  }
}

// Make array of value items
function makeValueArray(pName) {
  
  var returnArray = [];
  $("input[name='" + pName + "']").each(function(){
    returnArray.push($(this).val());
  });

  return returnArray;
}

// Return a function to check the length of a field - to be assigned to event
function genFunLengthCheckValue(pMaxLength, pFieldName, pElementId) {
	
  return function() {
    var self = document.getElementById(pElementId);
    var extraCut = 0;

    var checkLinefeed = self.value.charAt(pMaxLength - 1);
    if (checkLinefeed == '\r') {
      extraCut = 1;
    }

    if (self.value.length > pMaxLength) { 
      alert(pFieldName + " can only accept " +  pMaxLength + " characters.\n\n" + "Your input has been reduced to this length.");
      self.value = self.value.substr(0, pMaxLength - extraCut);
      self.focus();
      return false;
    }
    return true;
  }
}

// Add events to element preventing too much data entry
function restrictLength(pElementId, pMaxLength, pFieldName) {
  var elementObj = document.getElementById(pElementId);

  $(elementObj).on('change keyup keydown mouseup', genFunLengthCheckValue(pMaxLength, pFieldName, pElementId));
}  
  
// Add events to array of elements preventing too much data entry
function restrictLengthAllName(pName, pMaxLength, pFieldName) {
  var objArray = document.getElementsByName(pName);

  for (var x = 0; x < objArray.length; x++) {
    
    if (objArray[x].id == '') {
      objArray[x].id = pName + '_' + x;
    }
      
    restrictLength(objArray[x].id, pMaxLength, pFieldName);
  }
}

// Find a link from a clicked TD cell (on the same row)
function findLink($pCell) {
  return $pCell.closest('tr').find("td a.clickAnywhere").attr("href");
}
  
// Make whole interactive Report row click-able (open anchor tag)
function tableRowsClickAnywhere(pRowsSelector, pToolTip) {

  pToolTip = typeof pToolTip !== 'undefined' ? pToolTip : "Click to view detail";

  // Passed pRowsSelector - which table rows to add events to: ".a-IRR-table tr"
  
  var rowCount = 0;
  var $editCell = '';
  var linkAddress = '';

  $(pRowsSelector).each(function() {

    rowCount++;
    $editCell = $(this).find('td a').parent();
	
	  linkAddress = $editCell.find("a").attr("href");

    if (rowCount > 1 && typeof linkAddress !== "undefined") {
      
      // Apply event to all cells (apart from ones with a NOCLICK header attribute)
      $(this).find('td').not('td[headers*="NOCLICK"]').each(function() {
        $(this).attr("title",pToolTip);  
        $(this).addClass("cursorPointer");  
        $(this).on("click", function(){window.location = findLink($(this));});
      }); 
    
    }

  });
    
}


// Only allow number entry   Usage: onKeyPress="return onlyNum(event)"
function onlyNum(evt){
  evt = (evt) ? evt : window.event;
  var charCode = (evt.which) ? evt.which : evt.keyCode;
  if (charCode > 31 && (charCode < 48 || charCode > 57))
    {
    //alert('This field accepts numbers only.');
    return false;
    }

  return true;
}

</script>