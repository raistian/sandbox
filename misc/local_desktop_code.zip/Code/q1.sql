select * from parameter where parameter_id = 23;
select * from form where name = 'LS Assessment'; -- form_id = 3
select * from episode where client_id = 52602471;
select * from assessment where assessment_id = 36;
select * from answer_set where answer_set_id = 3;
select * from answer where answer_set_id = 3; --in (9,10);
select * from section where form_id = 4;
select * from assessment_outcome where assessment_id = 36;
select * from question_relationship where param_function_id is not null; --question_id = 186;
select * from question where section_id = 3;
select yjat_utility_pkg.get_parameter_value(null,'FORM_TYPE','ASSESSMENT') zz from dual;
select yjat_utility_pkg.get_parameter_value(27) zz from dual;
select yjat_assessment_pkg.get_assessment_status(assessment_id) from assessment where assessment_id = 1;

-- --
select
  e.episode_id,
  a.assessment_id,
  a.form_id,
  e.client_id,
  -- e.param_location_id,
  -- e.param_interview_reason_id,
  a.skipped_flag,
  a.skip_reason,
  (select client_name from client_v where client_id = e.client_id) as client_name,
  e.interview_date,
  (select description from parameter where parameter_id = e.param_interview_reason_id) as "Inteview Reason",
  (select value from parameter where parameter_id = e.param_location_id) as "Location",
  (select name from form where form_id = a.form_id) as form_name,
  a.user_id
from episode e
join assessment a on e.episode_id = a.episode_id
where 1 = 1
and e.active_flag = 'Y'
--and a.create_by = 'AACHRIST'
--and a.form_id < 5 -- Only Y/LS Screening an Assessment
and e.client_id = 52602471
;
-- start: hierarchy --
with
  a as ( -- episode, assessment, form
    select
      e1.episode_id,
      e1.client_id,
      e1.interview_date,
      yjat_utility_pkg.get_parameter_value(e1.param_interview_reason_id) as interview_reason,
      e1.active_flag as episode_active_flag,
      a1.assessment_id,
      yjat_utility_pkg.get_parameter_value(f1.param_assessment_type_id) as assessment_type,
      a1.create_by as assessment_create_by,
      a1.update_by as assessment_update_by,
      f1.form_id,
      f1.form_code
    from
      episode e1
      left join assessment a1 on e1.episode_id = a1.episode_id
      join form f1 on a1.form_id = f1.form_id
  ),
  s as ( -- plus section
    select
      a.*,
      s1.section_id,
      s1.name as section_name,
      s1.short_name as section_short_name
    from
      section s1
      join a on s1.form_id = a.form_id
  ),
  q as ( -- plus question
    select
      s.*,
      q1.question_id,
      q1.parent_id,
      q1.answer_set_id,
      q1.order_seq,
      q1.question_reference,
      q1.question_short
    from
      question q1
      join s on q1.section_id = s.section_id
  )
select *
from a
where 1 = 1
--and assessment_create_by = 'AACHRIST'
and form_id in (3,4)
and client_id = 52602471
;
-- end: hierarchy --
select pg.name,
  p.*
from parameter_group pg
join parameter p on pg.parameter_group_id = p.parameter_group_id
where pg.name like '%REASON%'
;
-- --
select
    yjat_main_pkg.display_user_title_fullname(ass.user_id),
    ass.user_id,
    ass.episode_id,
    ass.form_id,
    to_char(ass.update_dt, 'DD/MM/YYYY HH24:MI:SS'),
    yjat_utility_pkg.get_parameter_value(ass.param_interview_reason_id)
from assessment ass;
-- --
select s.section_id,
  q.question_id,
  q.parent_id,
  q.order_seq,
  q.question_reference
from section s
join question q on s.section_id = q.section_id
where 1 = 1
and s.form_id = 4
--and (q.question_reference = '1.' or q.parent_id = 126)
and q.parent_id = 126
order by q.order_seq
;

-- --
    select distinct
      q.section_id,
      q.question_id,
      q.parent_id,
      level,
      q.order_seq,
      q.question_reference,
      a.answer_id,
      a.answer_text,
      a.score,
      q.question_text,
      'qa'||q.question_id||'-'||a.answer_id as dom_id
    from question q
    join answer   a on q.answer_set_id = a.answer_set_id
    start with
      q.question_id = ( select q1.question_id
                        from question q1
                        join section s1 on q1.section_id = s1.section_id
                        where s1.form_id = 4
                        and q1.question_reference = '1.1' )
    connect by prior
      q.question_id = q.parent_id
order by q.question_id
;
-- --
select qp.question_id,
  qp.answer_id,
	yjat_utility_pkg.get_parameter_value(qp.param_check_function_id) ck_function,
  qp.param_matchtype_id,
	qp.value_1, 
  qp.value_2,
  qp.param_link_function_id,
	qp.param_inline_modal_id
from question_prepopulate qp
--where qp.question_id = 174 --:p_question_id
;
-- --
select e.episode_id,
  e.client_id,
  a.assessment_id,
  a.create_by,
  a.update_by,
  o.question_id,
  o.answer,
  o.answer_id,
  o.answerable_flag,
  o.create_by,
  o.update_by
from episode    e
join assessment a on (a.episode_id = e.episode_id)
left join assessment_outcome o on (a.assessment_id = o.assessment_id)
where 1 = 1
and a.assessment_id = 36
;
-- Episode History --
    select
      ep.*,
      rfi.description as reason_for_interview,
      loc.value as location,
      '<span class="fa fa-info-circle extraInfo" aria-hidden="true" title="' ||
      'Disability: ' || yjat_episode_pkg.has_disability(ep.episode_id) || 
      ' Refugee: '   || yjat_episode_pkg.is_refugee(ep.episode_id) || 
      ' Comments: '  || ep.comments ||
      '"></span>' as extra_information
    from 
      episode ep
    join parameter rfi on (rfi.parameter_id = ep.param_interview_reason_id)  
    join parameter loc on (loc.parameter_id = ep.param_location_id)
    where 
      ep.client_id = :p_client_id
    order by
      ep.interview_date desc
;

-- Assessment History --
    select 
      ep.interview_date,
      fm.name as form_name,
      to_number(yjat_assessment_pkg.get_assessment_rating(assessment_id,'SCORE')) as score,
      yjat_assessment_pkg.get_assessment_rating(assessment_id) as rating,
      case -- Use overriden rating if approved
        when yjat_assessment_pkg.get_override_status(assessment_id) = yjat_utility_pkg.get_parameter_value(null,'ASSESSMENT_OVERRIDE_STATUS','Approved')
        then override_requested_rating
      end as approved_rating,
      yjat_main_pkg.display_user_title_fullname(ass.user_id) as interviewer,
      yjat_assessment_pkg.get_assessment_status(ass.assessment_id) as status,
      yjat_assessment_pkg.get_assessment_status(ass.assessment_id, 'COUNTOF') as status_countof,
      yjat_assessment_pkg.show_assessment_buttons(ass.assessment_id, :p_application_id, :p_session_id, :p_current_user) as assessment_buttons
    from 
      episode ep
    join assessment ass      on (ass.episode_id = ep.episode_id)
    join form fm             on (fm.form_id = ass.form_id)
    left outer join users us on (us.user_id = ass.user_id)
    where 
      ep.episode_id = :p_episode_id
    order by
      fm.order_seq
;

-- --
--update question_relationship
--set answer_id_affected = 29 -- original = 10
--where question_relationship_id in (515, 516)
--;

