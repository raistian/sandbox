var woo = function(pAssessmentId) {
  var callback   = 'genModalDialogUrl';
  var dialogPage = 110;
  
  $('.t-Button--warning.assessmentHistory').each(function(i,e) {
    if ($(e).attr('onclick') === 'skipForm('+pAssessmentId+')') {
      apex.server.process(callback,
        { 'x01': dialogPage,
          'x02': pAssessmentId,
        },
        { 'dataType': 'text',
          'success': function(url) {
            $(e).css('color','red');
            $(e).attr('onclick',url);
          }
        }
      );
    }
  });

} // end of function

// Call dynamic action to update page items and refresh report region
//$.event.trigger('refreshClientWorkflow');
  
//submitSkipReason

//apex.submit({ request:"SUBMIT"});

//apex.jQuery( apex.gPageContext$ ).on( "apexpagesubmit", function() {
//  $.event.trigger('refreshClientWorkflow');
//});


// Page 110 JavaScript
var saveProcess = function() {
  console.log('saveProcess(): called');

  var callback     = 'saveProcess';
  var assessmentId = $('#P110_ASSESSMENT_ID').val();
  var skipReason   = $('#P110_SKIP_REASON').val();
    
  apex.server.process(callback,
    { 'x01': assessmentId,
      'x02': skipReason,
    },
    { 'dataType': 'json',
      'success': function(result) {
        console.log(result);
        apex.navigation.dialog.close(true, false);
        $.event.trigger('refreshClientWorkflow');
      }
    }
  );

}


// Page Load
restrictLength('P110_SKIP_REASON', 200, 'Skip Reason'); // The function is declared in Page Zero

$('#saveBtn').click(function() {
  saveProcess();
});