// JS Promise
  var ajx = function() {
    return apex.server.process('calcWarning',{});
  }
  ajx().then(function(data) {
    console.log(data);
  }, 'Error msg here');