with
  -- Capabilities & Tasks. Steps & Questions show up even if they have no answers yet.
  cap as (
    select
      c.capability_id,
      t.task_id,
      sc.scenario_id,
      s.step_id,
      s.element_id,
      s.question_id,
      c.name                as capability_name,
      c.description         as capability_description,
      sc.name               as scenario_name,
      utility_pkg.get_parameter_value(c.param_finyear_id) as fin_year,
      utility_pkg.get_parameter_value(a.param_assmnt_status_id) as capability_status,
      t.name                as task_name,
      t.description         as task_description,
      g.description         as target_description,
      s.step_name,
      s.element_name,
      s.question_text,
      s.element_order,
      utility_pkg.get_parameter_value(a.param_conf_rating_id) as confidence_rating,
      a.param_source_of_info_id,
      a.summary_comments,
      a.review_comments,
      a.start_dt,
      a.start_by,
      a.finish_dt,
      a.finish_by,
      a.create_dt,
      a.create_by,
      a.update_dt,
      a.update_by
    from
      capability                c
      join capability_scenario  cs on (c.capability_id = cs.capability_id)
      join scenario             sc on (cs.scenario_id = sc.scenario_id)
      join task                 t  on (c.capability_id = t.capability_id)
      join target               g  on (t.task_id = g.task_id)
      join assessment           a  on (c.capability_id = a.capability_id)
      -- Cross Join since every Capability has Steps + Elements (Step 1 to 4) + Questions (Step 5)
      cross join (
        select
          s1.step_id,
          s1.name         as step_name,
          e1.element_id,
          e1.name         as element_name,
          null as question_id,
          null as question_text,
          e1.order_seq as element_order
        from
          step s1
          cross join element e1
        where upper(s1.name) in ('STEP 1','STEP 2','STEP 3','STEP 4')
        union all
        select
          s2.step_id,
          s2.name,
          null as element_id,
          null as element_name,
          q2.question_id,
          q2.question_text,
          null
        from
          step s2
          join question q2 on (q2.step_id = s2.step_id)
          where upper(s2.name) = 'STEP 5'
      ) s
    where
      c.active_status_flag = 'Y'
  ),
  -- Assessment details (answers).
  ad as (
    select * from assessment_detail
  )
select
  cap.capability_name,
  cap.capability_description,
  cap.scenario_name,
  cap.task_name,
  cap.task_description,
  cap.target_description,
  cap.step_name,
  cap.element_name,
  ad.element_type,
  ad.unit_measure,
  ad.explanation,
  ad.gap_description,
  ad.accepted_flag,
  cap.question_text,
  ad.question_answer,
  utility_pkg.lov_id_to_txt(ad.leverage_area, 'AREAS_TO_LEVERAGE_FROM', ad.comments) as leverage_area,
  cap.element_order,
  cap.capability_status,
  cap.confidence_rating,
  utility_pkg.lov_id_to_txt(cap.param_source_of_info_id,'SOURCE_OF_INFO') as source_of_info,
  cap.summary_comments,
  cap.review_comments,
  cap.finish_dt,
  cap.create_dt,
  cap.update_dt
from
  cap
  left join ad on (
    -- This joining method is necessary because assessment detail can be joined CONDITIONALLY by various id columns.
    -- ie. Question_Id is FK to Question table when it's Step 5; Element_Id when it's Step 2, etc.
    nvl(cap.task_id,-1) = nvl(ad.task_id,-1)
    and nvl(cap.step_id,-1) = nvl(ad.step_id,-1)
    and nvl(cap.element_id,-1) = nvl(ad.element_id,-1)
    and nvl(cap.question_id,-1) = nvl(ad.question_id,-1)
  )
