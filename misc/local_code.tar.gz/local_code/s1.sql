with
  ans as (
    select
      q.order_seq
    , d.leverage_area
    , q.question_text
    , d.question_answer
      -- --
    , q.question_id
    , d.assessment_detail_id
    , q.step_id
    , q.param_question_type_id
    from question q
    left join assessment_detail d on (q.question_id = d.question_id)
    where q.step_id = 5
    order by q.order_seq
  )
, lev as (
    select assessment_detail_id, regexp_substr(leverage_area, '[^:]+', 1, level) as row_area
    from   ans
    connect by regexp_substr(leverage_area, '[^:]+', 1, level) is not null
  )
, cmj as (
    select
      p.value_txt d
    , p.application_param_id r
    from common_doj.param_group g
    join common_doj.application_param p on (g.param_group_id = p.param_group_id)
    join lev l on (p.application_param_id = l.row_area)
    where g.group_key = 'AREAS_TO_LEVERAGE_FROM'
  )
select *
from cmj
;

select
  q.order_seq
, q.question_text
, d.question_answer
, d.leverage_area
  -- --
, q.question_id
, d.assessment_detail_id
, q.step_id
, q.param_question_type_id
--, :p6_task_id as task_id
-- , ( with lov as (select d.leverage_area lov_col from dual)
--       select regexp_substr(lov_col, '[^:]+', 1, level)
--       from   lov
--       connect by level <= length(regexp_replace(lov_col, '[^:]+')) + 1
--   ) as rslt
, ( regexp_substr( d.leverage_area, '[^:]+', 1, level) connect by level < 2 ) z
from question q
left join assessment_detail d on (q.question_id = d.question_id)
where q.step_id = 5
order by q.order_seq
;

with test as
      (select '421907802490;421907672085;421911460415;421905464170;421907802292' col from dual)
    select regexp_substr(col, '[^;]+', 1, level) result
    from test
    connect by level <= length(regexp_replace(col, '[^;]+')) + 1;

select regexp_substr('2542:2544','[^:]+', 1, level)
from dual
connect by regexp_substr('2542:2544', '[^:]+', 1, level) is not null
;
