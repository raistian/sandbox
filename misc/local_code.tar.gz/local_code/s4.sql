select
  c.name                as capability_name,
  c.description         as capability_description,
  sc.name               as scenario_name,
  utility_pkg.get_parameter_value(c.param_finyear_id) as fin_year,
  utility_pkg.get_parameter_value(a.param_assmnt_status_id) as capability_status,
  t.name                as task_name,
  t.description         as task_description,
  s.name            as step_name,
  e.name            as element_name,
  e.element_type,
  e.unit_measure,
  e.explanation,
  e.gap_description,
  e.accepted_flag,
  q.question_text,
  q.question_answer
--  s.assessment_detail_id stp_dtl_id,
--  e.assessment_detail_id elm_dtl_id,
--  q.assessment_detail_id qst_dtl_id
from
  capability                c
  join capability_scenario  cs on (c.capability_id = cs.capability_id)
  join scenario             sc on (cs.scenario_id = sc.scenario_id)
  join task                 t  on (c.capability_id = t.capability_id)
  join assessment           a  on (c.capability_id = a.capability_id)
  join (
    select
      s1.step_id,
      s1.order_seq,
      s1.name,
      d1.task_id,
      d1.assessment_detail_id,
      utility_pkg.get_parameter_value(d1.param_task_status_id) as step_task_status
    from
      step s1
      left join assessment_detail d1 on (s1.step_id = d1.step_id)
  ) s on (t.task_id = s.task_id)
  left join (
    select
      e1.element_id,
      e1.order_seq,
      e1.name,
      d1.task_id,
      d1.assessment_detail_id,
      d1.element_type,
      d1.unit_measure,
      d1.explanation,
      d1.gap_description,
      d1.accepted_flag
    from
      element e1
      left join assessment_detail d1 on (e1.element_id = d1.element_id)
  ) e on (s.assessment_detail_id = e.assessment_detail_id)
  left join (
    select
      q1.question_id,
      q1.order_seq,
      q1.question_text,
      d1.task_id,
      d1.assessment_detail_id,
      d1.question_answer
    from
      question q1
      left join assessment_detail d1 on (q1.question_id = d1.question_id)
  ) q on (s.assessment_detail_id = q.assessment_detail_id)
where
  c.active_status_flag = 'Y'
  and c.capability_id = 141
  and t.task_id = 181
  and s.step_id in(4,5)
order by
  t.order_seq, -- task
  s.order_seq  -- step
--------------------------------------------------
select
  c.name                as capability_name,
  c.description         as capability_description,
  sc.name               as scenario_name,
  utility_pkg.get_parameter_value(c.param_finyear_id) as fin_year,
  utility_pkg.get_parameter_value(a.param_assmnt_status_id) as capability_status,
  t.name                as task_name,
  t.description         as task_description,
  s.name         as step_name,
  e.name         as element_name,
  q.question_text,
  q.question_answer,
  s.assessment_detail_id stp_dtl_id,
  e.assessment_detail_id elm_dtl_id,
  q.assessment_detail_id qst_dtl_id
from
  capability                c
  join capability_scenario  cs on (c.capability_id = cs.capability_id)
  join scenario             sc on (cs.scenario_id = sc.scenario_id)
  join task                 t  on (c.capability_id = t.capability_id)
  join assessment           a  on (c.capability_id = a.capability_id)
  join (
    select
      d1.task_id,
      d1.assessment_detail_id,
      s1.step_id,
      s1.order_seq,
      s1.name
    from
      step s1
      left join assessment_detail d1 on (s1.step_id = d1.step_id)
  ) s on (t.task_id = s.task_id)
  left join (
    select
      d1.task_id,
      d1.assessment_detail_id,
      e1.element_id,
      e1.order_seq,
      e1.name
    from
      element e1
      left join assessment_detail d1 on (e1.element_id = d1.element_id)
  ) e on (t.task_id = e.task_id and s.assessment_detail_id = e.assessment_detail_id)
  left join (
    select
      d1.task_id,
      d1.assessment_detail_id,
      d1.question_answer,
      q1.question_id,
      q1.order_seq,
      q1.question_text
    from
      question q1
      left join assessment_detail d1 on (q1.question_id = d1.question_id)
  ) q on (t.task_id = q.task_id and s.assessment_detail_id = q.assessment_detail_id)
where
  c.active_status_flag = 'Y'
  and c.capability_id = 141
  and t.task_id = 181
  and s.step_id in(1,5)
order by
  t.order_seq, -- task
  s.order_seq  -- step
;
--------------------------------------------------
select
  c.name                as capability_name,
  c.description         as capability_description,
  utility_pkg.get_parameter_value(c.param_finyear_id) as fin_year,
  c.active_status_flag  as capability_active_flag,
  sc.name               as scenario_name,
  t.name                as task_name,
  t.description         as task_description,
  c.capability_id,
  t.task_id,
  t.order_seq           as task_ord_seq,
  utility_pkg.get_parameter_value(a.param_assmnt_status_id) as assessment_status,
  s.step_id,
  s.name                as step_name,
  s.description         as step_desc,
  --case
  --  when upper(s.name) = 'STEP 5' then null -- Step 5 does not have elements.
  --  else e.name
  --end as element_name,
  e.name as element_name,
  q.question_text
from
  capability                c
  join capability_scenario  cs on (c.capability_id = cs.capability_id)
  join scenario             sc on (cs.scenario_id = sc.scenario_id)
  join task                 t  on (c.capability_id = t.capability_id)
  left join assessment      a on (c.capability_id = a.capability_id)
  -- Cross Joins are used since all Capabilities shares steps & elements.
  cross join step           s
  cross join element        e
  left join (
    select
      q1.question_id,
      q1.question_text,
      q1.param_question_type_id,
      q1.order_seq,
      utility_pkg.get_parameter_code( q1.param_question_type_id ) as question_param_code,
      case
        when utility_pkg.get_parameter_code( q1.param_question_type_id ) = 'STEP5' then 5
        else null
      end as step_id
    from
      question q1
  ) q on s.step_id = q.step_id
where
  c.capability_id = 141
  and t.task_id = 181
order by
  t.order_seq,
  s.order_seq,
  q.order_seq
;
-- Capability + Scenario + Task
select
  c.name                as capability_name,
  c.description         as capability_description,
  utility_pkg.get_parameter_value(c.param_finyear_id) as fin_year,
  c.active_status_flag  as capability_active_flag,
  sc.name               as scenario_name,
  t.name                as task_name,
  t.description         as task_description,
  c.capability_id,
  t.task_id,
  t.order_seq           as task_ord_seq
from
  capability                c
  join capability_scenario  cs on (c.capability_id = cs.capability_id)
  join scenario             sc on (cs.scenario_id = sc.scenario_id)
  join task                 t  on (c.capability_id = t.capability_id)
where
  c.capability_id = 141
  and t.task_id = 181
;
-- Question left join AssessmentDetail
select
  q.question_id,
  q.question_text,
  utility_pkg.get_parameter_code( q.param_question_type_id ) as question_param_code,
  d.question_id  as ad_question_id,
  d.step_id      as ad_step_id,
  d.question_answer,
  d.element_type,
  d.unit_measure,
  d.explanation,
  d.gap_description,
  d.accepted_flag,
  d.leverage_area,
  d.comments
from
  question q
  left join assessment_detail d on (q.question_id = d.question_id)
where
  d.task_id = 181
;
--------------------------------------------------
