select
  a.application_id
, a.acronym
  -- --
, g.param_group_id
, g.group_key
, g.group_name
, g.user_editable_flg
  -- --
, p.application_param_id
, p.code
, p.description
, p.active_flg
, p.value_txt
, p.ordering
from application a
join param_group g on a.application_id = g.application_id
join application_param p on g.param_group_id = p.param_group_id
where a.acronym = 'CAP'
order by a.application_id, g.param_group_id, p.ordering, p.value_txt
;

select
  authorisation_pkg.get_role_id('SYSTEM') system_user
, authorisation_pkg.get_role_id('ADMIN') admin_user
, authorisation_pkg.get_role_id('USER') normal_user
from dual;

-- LOGIN_SYSTEM_ROLE = 'Y'
-- SYSTEM_ROLE = 'Y'
-- ADMIN_ROLE = 'Y'
-- USER_ROLE = 'Y'
