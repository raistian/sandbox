select * from capability where capability_id = 141;
select * from task where task_id in (181,182);
--delete from assessment_detail where task_id in (181,182);
select * from step;
select * from element;
select * from assessment_detail;
select * from assessment;

select
  utility_pkg.get_parameter_value( a.param_assmnt_status_id ) as assmnt_status_val,
  a.param_source_of_info_id,
  a.summary_comments,
  a.review_comments,
  utility_pkg.get_parameter_value( a.param_conf_rating_id ) as conf_rating_val,
  utility_pkg.get_parameter_code( a.param_conf_rating_id ) as conf_rating_code
--into   l_conf_rtg_ans_ct
from   assessment a
where  a.capability_id = 141
--and    a.param_conf_rating_id is not null
;
