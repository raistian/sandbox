/**
 * Change old js function name to new one (Override without changing Apex).
**/
var moo = function() {
  var oldStr = 'showTasks';
  var newStr = 'setTasks';
  $('#report_ACTIVE_CAPABILITY_TASKS tbody tr td.t-Report-cell[]')
  $('#CARDS_cards div.t-Card a').each(function(idx, elm) {
    //console.log($(this).prop('href'));
    $(this).prop('href', $(this).attr('href').replace(oldStr, newStr));
  });
}
