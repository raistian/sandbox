select * from capability where name = 'Fatality Management'; -- capability_id=30
select * from task where name = '8.1'; -- task_id=57select

  c.name                            as card_title
, apex_string.get_initials(c.name)  as card_initials
, null                              as card_text
, null                              as card_subtext
--, 'f?p=&APP_ID:&APP_PAGE_ID.:&SESSION.::NO:RP:P5_CAPABILITY_ID:'||c.capability_id
, 'javascript:showTasks('||c.capability_id||')'
  as card_link
from capability c
join user_capability uc on c.capability_id = uc.capability_id
where uc.com_user_id = authorisation_pkg.get_user_id(:app_user)
;

insert into user_capability (capability_id, com_user_id)
select
  26 -- Intelligence and Information Sharing
, authorisation_pkg.get_user_id('andi.christian@justice.vic.gov.au')
from dual
;

select
  utility_pkg.get_parameter_value (null,'QUESTION_TYPE','STEP5') as step5
, utility_pkg.get_parameter_value (null,'QUESTION_TYPE','CONFIDENCE_RATING') as conf_rating
, utility_pkg.get_application_param_id(p_group_key => 'QUESTION_TYPE', p_code => 'STEP5') as z
, utility_pkg.get_parameter_code(2569) as param_code
, utility_pkg.get_parameter_value(2569) as param_val
, authorisation_pkg.get_user_id('andi.christian@justice.vic.gov.au') as user_id
from dual
;

/* Step 5 Question 1
Based on your expertise, where would be the most effective place to start looking for additional capability, or the most innovative? What avenues have been identified but not yet tried?
*/

/* Step 5 Question 2
What discussion are you aware of that may have already been identified, but further work or confirmation is still required? When is this expected?
*/
