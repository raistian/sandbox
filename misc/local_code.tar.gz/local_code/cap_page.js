/** Page Javascript **/
var showTasks = function(pCapabilityId, pCapabilityName) {
  $('#P5_CAPABILITY_NAME').val(pCapabilityName);
  $('#ACTIVE_CAPABILITY_TASKS_heading').text('Tasks for '+pCapabilityName);
  var callback = 'showTasks';
  apex.server.process(callback
  , { 'x01': pCapabilityId
    }
  , { 'datatype':'json',
      'success': function(data) {
        if (data.success) {
          if (data.result === 'YES') {
            $('.confidence_rating').text('Confidence Rating / Review');
          }
          else {
            $('.confidence_rating').text('Complete all tasks before providing Confidence Rating');
          }
          $('#ACTIVE_CAPABILITY_TASKS').trigger('apexrefresh');
        }
      }
    }
  );
}
