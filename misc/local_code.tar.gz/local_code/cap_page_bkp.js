/** Page Javascript **/
var showTasks = function(pCapabilityId, pCapabilityName) {
  $('#P5_CAPABILITY_NAME').val(pCapabilityName);
  var callback = 'showTasks';
  apex.server.process(callback
  , { 'x01': pCapabilityId
    }
  , { 'datatype':'json',
      'success': function(data) {
        if (data.success) {
          $('h2[id="ACTIVE_CAPABILITY_TASKS_heading"]').text('Tasks for ').append($('#P5_CAPABILITY_NAME').val());
          $('#ACTIVE_CAPABILITY_TASKS').trigger('apexrefresh');
        }
      }
    }
  );
}
