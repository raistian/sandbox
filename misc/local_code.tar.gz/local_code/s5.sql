with
  cap as (
    select
      c.capability_id,
      t.task_id,
      sc.scenario_id,
      s.step_id,
      s.element_id,
      s.question_id,
      c.name                as capability_name,
      c.description         as capability_description,
      sc.name               as scenario_name,
      utility_pkg.get_parameter_value(c.param_finyear_id) as fin_year,
      utility_pkg.get_parameter_value(a.param_assmnt_status_id) as capability_status,
      t.name                as task_name,
      t.description         as task_description,
      s.step_name,
      s.element_name,
      s.question_text
    from
      capability                c
      join capability_scenario  cs on (c.capability_id = cs.capability_id)
      join scenario             sc on (cs.scenario_id = sc.scenario_id)
      join task                 t  on (c.capability_id = t.capability_id)
      join assessment           a  on (c.capability_id = a.capability_id)
      -- Cross Join since every Capability has Steps + Elements (Step 1 to 4) + Questions (Step 5)
      cross join (
        select
          s1.step_id,
          s1.name         as step_name,
          e1.element_id,
          e1.name         as element_name,
          null as question_id,
          null as question_text
        from
          step s1
          cross join element e1
        where upper(s1.name) in ('STEP 1','STEP 2','STEP 3','STEP 4')
        union all
        select
          s2.step_id,
          s2.name,
          null as element_id,
          null as element_name,
          q2.question_id,
          q2.question_text
        from
          step s2
          join question q2 on (q2.step_id = s2.step_id)
          where upper(s2.name) = 'STEP 5'
      ) s
    where
      c.active_status_flag = 'Y'
      and c.capability_id = 141
      and t.task_id = 181
  ),
  ad as (
    select * from assessment_detail --where step_id in (1,2,3,4)
  )
select
  cap.capability_name,
  cap.scenario_name,
  cap.task_name,
  cap.step_name,
  cap.element_name,
  cap.question_text,
  ad.element_type,
  ad.unit_measure,
  ad.question_answer
from
  cap
  --left join ad on (cap.task_id = ad.task_id and cap.step_id = ad.step_id and cap.element_id = ad.element_id)
  left join ad on (
    nvl(cap.task_id,-1) = nvl(ad.task_id,-1)
    and nvl(cap.step_id,-1) = nvl(ad.step_id,-1)
    and nvl(cap.element_id,-1) = nvl(ad.element_id,-1)
    and nvl(cap.question_id,-1) = nvl(ad.question_id,-1)
  )
where
  cap.step_id = 5
--------------------------------------------------------------------------------
select
  c.name                as capability_name,
  c.description         as capability_description,
  sc.name               as scenario_name,
  utility_pkg.get_parameter_value(c.param_finyear_id) as fin_year,
  utility_pkg.get_parameter_value(a.param_assmnt_status_id) as capability_status,
  t.name                as task_name,
  t.description         as task_description,
  s.name            as step_name,
  e.name            as element_name,
  e.element_type,
  e.unit_measure,
  e.explanation,
  e.gap_description,
  e.accepted_flag,
  q.question_text,
  q.question_answer
--  s.assessment_detail_id  stp_dtl_id,
--  e.assessment_detail_id  elm_dtl_id,
--  q.assessment_detail_id  qst_dtl_id
from
  capability                c
  join capability_scenario  cs on (c.capability_id = cs.capability_id)
  join scenario             sc on (cs.scenario_id = sc.scenario_id)
  join task                 t  on (c.capability_id = t.capability_id)
  join assessment           a  on (c.capability_id = a.capability_id)
  join (
    select
      s1.step_id,
      s1.order_seq,
      s1.name,
      d1.task_id,
      d1.assessment_detail_id,
      utility_pkg.get_parameter_value(d1.param_task_status_id) as step_task_status
    from
      step s1
      left join assessment_detail d1 on (s1.step_id = d1.step_id)
  ) s on (t.task_id = s.task_id)
  left join (
    select
      e1.element_id,
      e1.order_seq,
      e1.name,
      d1.task_id,
      d1.assessment_detail_id,
      d1.element_type,
      d1.unit_measure,
      d1.explanation,
      d1.gap_description,
      d1.accepted_flag
    from
      element e1
      left join assessment_detail d1 on (e1.element_id = d1.element_id)
  ) e on (s.assessment_detail_id = e.assessment_detail_id)
  left join (
    select
      q1.question_id,
      q1.order_seq,
      q1.question_text,
      d1.task_id,
      d1.assessment_detail_id,
      d1.question_answer
    from
      question q1
      left join assessment_detail d1 on (q1.question_id = d1.question_id)
  ) q on (s.assessment_detail_id = q.assessment_detail_id)
where
  c.active_status_flag = 'Y'
  and c.capability_id = 141
  and t.task_id = 181
  and s.step_id in(4)
order by
  t.order_seq, -- task
  s.order_seq  -- step
