/******************
  Page Javascript
******************/
var confirmDelete = function(pId) {
  var deleteMsg = '"DELETE_CONFIRM_MSG"'; // Repurpose built-in Apex delete message.
  var apexAjaxCallback = 'deleteElement';
  apex.message.confirm(deleteMsg, function(bool) {
    if (bool) {
      apex.server.process( apexAjaxCallback
      , { 'x01':pId }
      , { 'dataType': 'json'
        , 'success': function(data) {
            apex.event.trigger('#PEOPLE_ELEMENT','apexrefresh');
          }
        }
      );
    }
  });
}

var deletableElement = function() {
  var titleTxt  = '"Delete Element"';
  var iconCls   = '"t-Icon fa fa-minus-square-o"';
  $('.deletableRow').each(function(i,e) {
    var recordId = $(e).text();
    $(e).html( '<a href="javascript:confirmDelete'+'('+recordId+')'+'" class='+iconCls+' title='+titleTxt+'></a>' );
  });
}
