// Can be used to call Dynamic Action: $.event.trigger('apexDynamicAction');
// Refresh apex region using js: apex.event.trigger('#static_id','apexrefresh');
var showTasks = function(pCapabilityId) {
  var callback = 'showTasks'
  apex.server.process(callback
  , { 'x01':pCapabilityId
    }
  , { 'datatype':'json',
      'success': function(data) {
        if (data.success) {
          $('#TASKS').trigger('apexrefresh');
        }
      }
    }
  );
}
