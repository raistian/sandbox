select
  u.first_name,
  u.last_name,
  u.email,
  r.role_short
from common_doj.com_user       u
join common_doj.com_user_role  ur on (ur.com_user_id = u.com_user_id)
join common_doj.role           r  on (ur.role_id = r.role_id)
join common_doj.application    a  on (r.application_id = a.application_id)
where a.acronym = 'CAP'
;

select *
from common_doj.com_user_role;

select
  uc.com_user_id
, ur.role_id
, authorisation_pkg.get_user_role_id(uc.com_user_id, ur.role_id) zz
from user_capability uc
join common_doj.com_user_role ur on (uc.com_user_id = ur.com_user_id)
;

select authorisation_pkg.is_admin z
from dual;



    -- get email template
    select
      email_subject,
      email_body
    into
      l_email_subject,
      l_email_body
    from
      common_doj.email_template
    where
      code = 'RESET_PASSWORD';

    -- Get user info
    select
      initcap(first_name) || ' ' || initcap(last_name),
      email
    into
      l_full_name,
      l_email
    from
      common_doj.com_user
    where
      upper(username) = upper(p_username);


declare
  l_ret     pls_integer := 0;
begin
  for app in (select * from apex_applications where alias = 'CAP') loop
    apex_util.set_security_group_id(p_security_group_id => app.workspace_id);
  end loop;
/*
  apex_mail.send(
    p_to    => 'andi.a.christian@justice.vic.gov.au'
  , p_from  => 'donotreply@capability.em.vic.gov.au'
  , p_body  => 'test'
  , p_body_html  => '<p>Test html paragraph</p>'
  , p_subj       => 'subj (test)'
  , p_replyto  => 'donotreply@capability.em.vic.gov.au'
  );
 */
  apex_mail.push_queue;
end;
